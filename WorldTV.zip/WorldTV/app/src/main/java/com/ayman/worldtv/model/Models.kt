package com.ayman.worldtv.model

data class StreamSource(
    val url: String,
    val userAgent: String? = null,
    val referrer: String? = null,
    val quality: String? = null,
)

data class Channel(
    val id: String,
    val name: String,
    val normName: String,
    val logo: String?,
    val countryCode: String?,
    val categories: List<String>,
    val languages: List<String>,
    val streams: List<StreamSource>,
    val geoBlocked: Boolean,
    val notAlwaysOn: Boolean,
    val searchKey: String,
) {
    val primaryCategory: String get() = categories.firstOrNull() ?: "undefined"
    val bestQuality: String?
        get() = streams.mapNotNull { it.quality }
            .maxByOrNull { q -> q.filter(Char::isDigit).toIntOrNull() ?: 0 }
}

/**
 * WORKING / FAILED come from real playback.
 * REACHABLE / UNREACHABLE come from the link check, which only proves the server answers.
 */
enum class ChannelStatus { UNKNOWN, WORKING, FAILED, REACHABLE, UNREACHABLE }

data class StatusRecord(val status: ChannelStatus, val time: Long)

data class PlaylistSource(
    val id: String,
    val name: String,
    val url: String,
    val enabled: Boolean = true,
    val builtIn: Boolean = false,
) {
    val isLocal: Boolean get() = url.startsWith("local:")
}

data class HistoryEntry(val channelId: String, val time: Long)

enum class ThemeMode { SYSTEM, DARK, LIGHT }

enum class SortOrder { NAME, COUNTRY, CATEGORY }

enum class DataSaverMode { OFF, MOBILE_ONLY, ALWAYS }

data class ChannelList(val id: String, val name: String, val channelIds: List<String>)

data class CheckProgress(val done: Int, val total: Int)

data class AppSettings(
    val wifiOnly: Boolean = false,
    val warnOnMobile: Boolean = true,
    val theme: ThemeMode = ThemeMode.DARK,
    val dailyWarningMb: Int = 0,
    val dataSaver: DataSaverMode = DataSaverMode.MOBILE_ONLY,
    val backgroundAudio: Boolean = false,
)

data class CountryCount(val code: String, val count: Int)

data class CategoryCount(val key: String, val count: Int)

data class Catalog(
    val channels: List<Channel> = emptyList(),
    val byId: Map<String, Channel> = emptyMap(),
    val countries: List<CountryCount> = emptyList(),
    val categories: List<CategoryCount> = emptyList(),
    val languages: List<String> = emptyList(),
    val sourceCount: Int = 0,
    val loading: Boolean = false,
    val lastUpdated: Long = 0L,
    val sourceErrors: List<String> = emptyList(),
    val usingCache: Boolean = false,
)
