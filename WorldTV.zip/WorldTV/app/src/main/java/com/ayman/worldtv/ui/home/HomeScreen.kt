package com.ayman.worldtv.ui.home

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.LiveTv
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.model.Catalog
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.ui.components.ChannelCard
import com.ayman.worldtv.ui.components.ChannelLogo
import com.ayman.worldtv.ui.components.EmptyState
import com.ayman.worldtv.ui.components.SectionHeader
import com.ayman.worldtv.ui.components.channelSubtitle
import com.ayman.worldtv.ui.theme.Spacing
import com.ayman.worldtv.ui.theme.WtvColors
import com.ayman.worldtv.util.Categories
import com.ayman.worldtv.util.Countries
import com.ayman.worldtv.util.categoryLabel
import com.ayman.worldtv.util.countryName

@Composable
fun HomeScreen(
    onSearch: () -> Unit,
    onCategory: (String) -> Unit,
    onCountry: (String) -> Unit,
    onAllCountries: () -> Unit,
    onFavorites: () -> Unit,
    onSettings: () -> Unit,
    onPlay: (Channel, List<Channel>) -> Unit,
) {
    val repo = LocalContext.current.app.repository
    val catalog by repo.catalog.collectAsStateWithLifecycle()
    val favoriteIds by repo.prefs.favorites.collectAsStateWithLifecycle()
    val history by repo.prefs.history.collectAsStateWithLifecycle()

    val recent = remember(catalog, history) { history.mapNotNull { catalog.byId[it.channelId] } }
    val favorites = remember(catalog, favoriteIds) { catalog.channels.filter { it.id in favoriteIds } }
    val categories = remember(catalog) {
        val counts = catalog.categories.associate { it.key to it.count }
        Categories.featured.filter { (counts[it] ?: 0) > 0 }.map { it to (counts[it] ?: 0) }
    }

    LazyColumn(contentPadding = PaddingValues(bottom = Spacing.xxl)) {
        item { HomeHeader(loading = catalog.loading, onRefresh = { repo.refreshAsync() }, onSettings = onSettings) }
        item { SearchPill(onSearch) }
        item { CatalogBanner(catalog, onRetry = { repo.refreshAsync() }) }

        if (catalog.channels.isEmpty() && !catalog.loading) {
            item {
                EmptyState(
                    icon = Icons.Outlined.LiveTv,
                    title = stringResource(R.string.empty_catalog_title),
                    message = stringResource(R.string.empty_catalog_msg),
                    actionLabel = stringResource(R.string.open_settings),
                    onAction = onSettings,
                )
            }
        }

        recent.firstOrNull()?.let { last ->
            item { ContinueCard(last, onPlay = { onPlay(last, recent) }) }
        }

        if (recent.size > 1) {
            item { SectionHeader(stringResource(R.string.recently_watched)) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = Spacing.l),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.m),
                ) {
                    items(recent.drop(1), key = { "r_" + it.id }) { ch -> ChannelCard(ch, onClick = { onPlay(ch, recent) }) }
                }
            }
        }

        if (favorites.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.your_favorites), stringResource(R.string.see_all), onFavorites) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = Spacing.l),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.m),
                ) {
                    items(favorites, key = { "f_" + it.id }) { ch -> ChannelCard(ch, onClick = { onPlay(ch, favorites) }) }
                }
            }
        }

        if (categories.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.browse_categories)) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = Spacing.l),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.m),
                ) {
                    items(categories, key = { "c_" + it.first }) { (key, count) ->
                        CategoryTile(key, count, onClick = { onCategory(key) })
                    }
                }
            }
        }

        if (catalog.countries.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.top_countries), stringResource(R.string.see_all), onAllCountries) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = Spacing.l),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.m),
                ) {
                    items(catalog.countries.take(15), key = { "k_" + it.code }) { c ->
                        CountryTile(c.code, c.count, onClick = { onCountry(c.code) })
                    }
                }
            }
        }

        if (catalog.channels.isNotEmpty()) {
            item { CatalogFooter(catalog) }
        }
    }
}

@Composable
private fun HomeHeader(loading: Boolean, onRefresh: () -> Unit, onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = Spacing.l, end = Spacing.xs, top = Spacing.m, bottom = Spacing.xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(MaterialTheme.shapes.medium)
                .background(Brush.linearGradient(listOf(WtvColors.Cyan, WtvColors.CyanDeep))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.LiveTv, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(Spacing.m))
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
        if (loading) {
            CircularProgressIndicator(Modifier.padding(Spacing.m).size(22.dp), strokeWidth = 2.dp)
        } else {
            IconButton(onClick = onRefresh) { Icon(Icons.Outlined.Refresh, contentDescription = stringResource(R.string.refresh)) }
        }
        IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, contentDescription = stringResource(R.string.nav_settings)) }
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit) {
    Row(
        Modifier
            .padding(horizontal = Spacing.l, vertical = Spacing.s)
            .fillMaxWidth()
            .height(52.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = Spacing.l),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Outlined.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(Spacing.m))
        Text(
            stringResource(R.string.search_hint),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun CatalogBanner(catalog: Catalog, onRetry: () -> Unit) {
    when {
        catalog.loading && catalog.channels.isEmpty() -> Column(Modifier.padding(Spacing.l)) {
            Text(stringResource(R.string.loading_catalog), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(Spacing.s))
            LinearProgressIndicator(Modifier.fillMaxWidth().clip(CircleShape))
        }
        !catalog.loading && catalog.sourceErrors.isNotEmpty() && catalog.channels.isNotEmpty() -> Surface(
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            shape = MaterialTheme.shapes.large,
            modifier = Modifier.padding(horizontal = Spacing.l, vertical = Spacing.xs).fillMaxWidth(),
        ) {
            Row(Modifier.padding(start = Spacing.l, end = Spacing.xs), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.CloudOff, contentDescription = null, tint = WtvColors.Warning, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(Spacing.m))
                Text(stringResource(R.string.offline_cache), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                TextButton(onClick = onRetry) { Text(stringResource(R.string.retry)) }
            }
        }
    }
}

@Composable
private fun ContinueCard(channel: Channel, onPlay: () -> Unit) {
    Box(
        Modifier
            .padding(horizontal = Spacing.l, vertical = Spacing.m)
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(
                Brush.linearGradient(
                    listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.surfaceContainerHigh)
                )
            )
            .clickable(onClick = onPlay)
            .padding(Spacing.l)
    ) {
        Column {
            Text(
                stringResource(R.string.continue_watching).uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(Spacing.m))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ChannelLogo(channel.logo, channel.name, size = 64.dp)
                Spacer(Modifier.width(Spacing.l))
                Column(Modifier.weight(1f)) {
                    Text(channel.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        channelSubtitle(channel),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.height(Spacing.l))
            Button(
                onClick = onPlay,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(Spacing.s))
                Text(stringResource(R.string.watch))
            }
        }
    }
}

@Composable
private fun CategoryTile(key: String, count: Int, onClick: () -> Unit) {
    Column(
        Modifier
            .width(108.dp)
            .clip(MaterialTheme.shapes.large)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .clickable(onClick = onClick)
            .padding(Spacing.m),
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Categories.icon(key), contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(Spacing.m))
        Text(categoryLabel(key), style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            stringResource(R.string.channels_count, count),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CountryTile(code: String, count: Int, onClick: () -> Unit) {
    Column(
        Modifier
            .width(104.dp)
            .clip(MaterialTheme.shapes.large)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .clickable(onClick = onClick)
            .padding(Spacing.m),
    ) {
        Text(Countries.flag(code), fontSize = 30.sp)
        Spacer(Modifier.height(Spacing.s))
        Text(countryName(code), style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            stringResource(R.string.channels_count, count),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CatalogFooter(catalog: Catalog) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = Spacing.l, vertical = Spacing.xl),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.AutoMirrored.Outlined.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(14.dp),
        )
        Spacer(Modifier.width(Spacing.s))
        val updated = if (catalog.lastUpdated > 0)
            DateUtils.getRelativeTimeSpanString(catalog.lastUpdated).toString()
        else stringResource(R.string.never)
        Text(
            stringResource(R.string.catalog_footer, catalog.channels.size, catalog.sourceCount) +
                " · " + stringResource(R.string.updated_at, updated),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
