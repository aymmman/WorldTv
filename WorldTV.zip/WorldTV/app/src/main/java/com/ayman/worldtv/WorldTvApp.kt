package com.ayman.worldtv

import android.app.Application
import android.content.Context
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.ayman.worldtv.data.ChannelRepository
import com.ayman.worldtv.data.Prefs

class WorldTvApp : Application(), ImageLoaderFactory {
    lateinit var prefs: Prefs
        private set
    lateinit var repository: ChannelRepository
        private set

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        repository = ChannelRepository(this, prefs)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .crossfade(true)
            .respectCacheHeaders(false)
            .build()
}

val Context.app: WorldTvApp
    get() = applicationContext as WorldTvApp
