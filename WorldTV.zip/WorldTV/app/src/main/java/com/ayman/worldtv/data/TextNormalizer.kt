package com.ayman.worldtv.data

import java.text.Normalizer
import java.util.Locale

/** Case-insensitive, accent-insensitive normalization with Arabic letter folding. */
object TextNormalizer {
    private val whitespace = Regex("\\s+")

    fun normalize(input: String): String {
        val decomposed = Normalizer.normalize(input.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        val sb = StringBuilder(decomposed.length)
        for (c in decomposed) {
            if (Character.getType(c) == Character.NON_SPACING_MARK.toInt()) continue
            when (c) {
                'أ', 'إ', 'آ', 'ٱ' -> sb.append('ا')
                'ة' -> sb.append('ه')
                'ى', 'ئ' -> sb.append('ي')
                'ؤ' -> sb.append('و')
                '\u0640' -> Unit // tatweel
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    fun tokens(query: String): List<String> =
        normalize(query).split(whitespace).filter { it.isNotBlank() }
}
