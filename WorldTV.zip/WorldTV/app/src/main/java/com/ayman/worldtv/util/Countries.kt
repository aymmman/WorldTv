package com.ayman.worldtv.util

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

object Countries {
    private val names = ConcurrentHashMap<String, String>()
    val ARABIC: Locale = Locale("ar")

    fun flag(code: String?): String {
        if (code == null || code.length != 2) return "\uD83C\uDF10" // globe
        val up = code.uppercase(Locale.ROOT)
        val first = Character.codePointAt(up, 0) - 'A'.code + 0x1F1E6
        val second = Character.codePointAt(up, 1) - 'A'.code + 0x1F1E6
        return String(Character.toChars(first)) + String(Character.toChars(second))
    }

    fun name(code: String?, locale: Locale): String {
        if (code.isNullOrBlank()) return ""
        val key = locale.language + ":" + code
        return names.getOrPut(key) {
            Locale("", code).getDisplayCountry(locale).ifBlank { code }
        }
    }
}

@Composable
fun countryName(code: String?): String {
    val locale = LocalConfiguration.current.locales[0]
    return Countries.name(code, locale)
}
