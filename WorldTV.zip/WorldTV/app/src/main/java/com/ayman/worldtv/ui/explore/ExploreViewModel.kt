package com.ayman.worldtv.ui.explore

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ayman.worldtv.data.ChannelRepository
import com.ayman.worldtv.data.TextNormalizer
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.model.ChannelStatus
import com.ayman.worldtv.model.SortOrder
import com.ayman.worldtv.model.StatusRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class ExploreFilters(
    val country: String? = null,
    val category: String? = null,
    val language: String? = null,
    val workedOnly: Boolean = false,
    val sort: SortOrder = SortOrder.NAME,
) {
    val active: Boolean get() = country != null || category != null || language != null || workedOnly
}

data class ExploreState(
    val results: List<Channel> = emptyList(),
    val ready: Boolean = false,
    val catalogLoading: Boolean = true,
    val catalogEmpty: Boolean = false,
)

@OptIn(FlowPreview::class)
class ExploreViewModel(
    private val repo: ChannelRepository,
    country: String?,
    category: String?,
) : ViewModel() {

    val query = MutableStateFlow("")
    val filters = MutableStateFlow(ExploreFilters(country = country, category = category))

    private val debouncedQuery = query
        .debounce(220)
        .map { it.trim() }
        .distinctUntilChanged()

    val state: StateFlow<ExploreState> =
        combine(repo.catalog, debouncedQuery, filters, repo.prefs.statuses) { catalog, q, f, statuses ->
            ExploreState(
                results = applyFilters(catalog.channels, q, f, statuses),
                ready = true,
                catalogLoading = catalog.loading,
                catalogEmpty = catalog.channels.isEmpty(),
            )
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ExploreState())

    fun setQuery(value: String) {
        query.value = value
    }

    fun commitSearch() = repo.prefs.addRecentSearch(query.value)

    fun update(transform: (ExploreFilters) -> ExploreFilters) {
        filters.value = transform(filters.value)
    }

    fun clearFilters() {
        filters.value = ExploreFilters(sort = filters.value.sort)
    }

    companion object {
        fun applyFilters(
            all: List<Channel>,
            query: String,
            f: ExploreFilters,
            statuses: Map<String, StatusRecord>,
        ): List<Channel> {
            val tokens = TextNormalizer.tokens(query)
            val filtered = all.filter { c ->
                (f.country == null || c.countryCode == f.country) &&
                    (f.category == null || f.category in c.categories) &&
                    (f.language == null || f.language in c.languages) &&
                    (!f.workedOnly || statuses[c.id]?.status == ChannelStatus.WORKING) &&
                    (tokens.isEmpty() || tokens.all { t -> c.searchKey.contains(t) })
            }
            val sorted = when (f.sort) {
                SortOrder.NAME -> filtered
                SortOrder.COUNTRY -> filtered.sortedWith(compareBy<Channel>({ it.countryCode ?: "~" }, { it.normName }))
                SortOrder.CATEGORY -> filtered.sortedWith(compareBy<Channel>({ it.primaryCategory }, { it.normName }))
            }
            if (tokens.isEmpty()) return sorted
            val phrase = tokens.joinToString(" ")
            return sorted.sortedBy {
                when {
                    it.normName == phrase -> 0
                    it.normName.startsWith(phrase) -> 1
                    it.normName.contains(phrase) -> 2
                    else -> 3
                }
            }
        }
    }
}
