package com.ayman.worldtv.player

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Owns the single ExoPlayer so audio can keep going after the player screen is closed.
 * The activity decides when to release it.
 */
object PlayerHolder {
    var player: ExoPlayer? = null
        private set

    /** Channel and link currently loaded into [player]. */
    var channelId: String? = null
    var streamIndex: Int = 0

    fun obtain(context: Context): ExoPlayer {
        player?.let { return it }
        val audio = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val created = ExoPlayer.Builder(context.applicationContext)
            .setAudioAttributes(audio, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = created
        return created
    }

    fun release(context: Context) {
        context.stopService(Intent(context, PlaybackService::class.java))
        player?.release()
        player = null
        channelId = null
        streamIndex = 0
    }
}

/** Media session service: notification, lock screen controls, and background audio. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val p = PlayerHolder.player ?: return
        val open = Intent(this, PlayerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pending = PendingIntent.getActivity(
            this, 0, open,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaSession.Builder(this, p).setSessionActivity(pending).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        // App swiped away from recents: stop everything.
        PlayerHolder.release(this)
        stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}
