package com.ayman.worldtv.ui.countries

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.data.TextNormalizer
import com.ayman.worldtv.ui.components.EmptyState
import com.ayman.worldtv.ui.components.ScreenTitle
import com.ayman.worldtv.ui.theme.Spacing
import com.ayman.worldtv.util.Countries
import java.text.Collator
import java.util.Locale

private data class CountryRowData(val code: String, val name: String, val count: Int, val key: String)

@Composable
fun CountriesScreen(onCountry: (String) -> Unit) {
    val repo = LocalContext.current.app.repository
    val catalog by repo.catalog.collectAsStateWithLifecycle()
    val locale = LocalConfiguration.current.locales[0]
    var query by rememberSaveable { mutableStateOf("") }

    val rows = remember(catalog, locale) {
        val collator = Collator.getInstance(locale)
        catalog.countries.map {
            val name = Countries.name(it.code, locale)
            CountryRowData(
                code = it.code,
                name = name,
                count = it.count,
                key = TextNormalizer.normalize(
                    name + " " + Countries.name(it.code, Locale.ENGLISH) + " " +
                        Countries.name(it.code, Countries.ARABIC) + " " + it.code
                ),
            )
        }.sortedWith { a, b -> collator.compare(a.name, b.name) }
    }
    val shown = remember(rows, query) {
        val tokens = TextNormalizer.tokens(query)
        if (tokens.isEmpty()) rows else rows.filter { r -> tokens.all { r.key.contains(it) } }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle(stringResource(R.string.nav_countries))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = Spacing.l),
            placeholder = { Text(stringResource(R.string.search_countries)) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            singleLine = true,
            shape = CircleShape,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
            ),
        )
        if (shown.isEmpty() && !catalog.loading) {
            EmptyState(
                icon = Icons.Outlined.Public,
                title = stringResource(if (catalog.channels.isEmpty()) R.string.empty_catalog_title else R.string.no_results_title),
                message = stringResource(if (catalog.channels.isEmpty()) R.string.empty_catalog_msg else R.string.no_results_msg),
            )
        }
        LazyColumn(contentPadding = PaddingValues(vertical = Spacing.s)) {
            items(shown, key = { it.code }) { row ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onCountry(row.code) }
                        .padding(horizontal = Spacing.l, vertical = Spacing.m),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(Countries.flag(row.code), fontSize = 26.sp)
                    Spacer(Modifier.width(Spacing.l))
                    Text(row.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    Text(
                        stringResource(R.string.channels_count, row.count),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Icon(
                        Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
