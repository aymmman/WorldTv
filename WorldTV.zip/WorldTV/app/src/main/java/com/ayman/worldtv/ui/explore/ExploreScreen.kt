package com.ayman.worldtv.ui.explore

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.model.ChannelStatus
import com.ayman.worldtv.model.SortOrder
import com.ayman.worldtv.ui.components.AddToListSheet
import com.ayman.worldtv.ui.components.ChannelRow
import com.ayman.worldtv.ui.components.EmptyState
import com.ayman.worldtv.ui.theme.Spacing
import com.ayman.worldtv.util.Countries
import com.ayman.worldtv.util.categoryLabel
import java.text.Collator

private enum class Sheet { COUNTRY, CATEGORY, LANGUAGE }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(
    initialCountry: String?,
    initialCategory: String?,
    autoFocus: Boolean,
    onPlay: (Channel, List<Channel>) -> Unit,
) {
    val repo = LocalContext.current.app.repository
    val vm: ExploreViewModel = viewModel(key = "explore_${initialCountry}_${initialCategory}") {
        ExploreViewModel(repo, initialCountry, initialCategory)
    }
    val state by vm.state.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val filters by vm.filters.collectAsStateWithLifecycle()
    val catalog by repo.catalog.collectAsStateWithLifecycle()
    val favorites by repo.prefs.favorites.collectAsStateWithLifecycle()
    val statuses by repo.prefs.statuses.collectAsStateWithLifecycle()
    val recentSearches by repo.prefs.recentSearches.collectAsStateWithLifecycle()

    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var openSheet by rememberSaveable { mutableStateOf<Sheet?>(null) }
    var sortMenu by remember { mutableStateOf(false) }
    var listSheetFor by remember { mutableStateOf<Channel?>(null) }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) { if (autoFocus) focusRequester.requestFocus() }
    LaunchedEffect(filters, query) { listState.scrollToItem(0) }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = vm::setQuery,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = Spacing.l, end = Spacing.l, top = Spacing.m)
                .focusRequester(focusRequester),
            placeholder = { Text(stringResource(R.string.search_hint), maxLines = 1, overflow = TextOverflow.Ellipsis) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { vm.setQuery("") }) {
                        Icon(Icons.Outlined.Clear, contentDescription = stringResource(R.string.clear))
                    }
                }
            },
            singleLine = true,
            shape = CircleShape,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.commitSearch(); focusManager.clearFocus() }),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
            ),
        )

        // Filter chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = Spacing.l, vertical = Spacing.s),
            horizontalArrangement = Arrangement.spacedBy(Spacing.s),
        ) {
            item {
                val code = filters.country
                FilterChip(
                    selected = code != null,
                    onClick = { openSheet = Sheet.COUNTRY },
                    label = {
                        Text(
                            if (code != null) Countries.flag(code) + " " + Countries.name(code, LocalConfiguration.current.locales[0])
                            else stringResource(R.string.filter_country)
                        )
                    },
                    trailingIcon = { Icon(Icons.Outlined.ArrowDropDown, contentDescription = null, modifier = Modifier) },
                )
            }
            item {
                val cat = filters.category
                FilterChip(
                    selected = cat != null,
                    onClick = { openSheet = Sheet.CATEGORY },
                    label = { Text(if (cat != null) categoryLabel(cat) else stringResource(R.string.filter_category)) },
                    trailingIcon = { Icon(Icons.Outlined.ArrowDropDown, contentDescription = null) },
                )
            }
            if (catalog.languages.isNotEmpty()) {
                item {
                    val lang = filters.language
                    FilterChip(
                        selected = lang != null,
                        onClick = { openSheet = Sheet.LANGUAGE },
                        label = { Text(lang ?: stringResource(R.string.filter_language)) },
                        trailingIcon = { Icon(Icons.Outlined.ArrowDropDown, contentDescription = null) },
                    )
                }
            }
            item {
                FilterChip(
                    selected = filters.workedOnly,
                    onClick = { vm.update { it.copy(workedOnly = !it.workedOnly) } },
                    label = { Text(stringResource(R.string.filter_worked)) },
                    leadingIcon = if (filters.workedOnly) {
                        { Icon(Icons.Outlined.Check, contentDescription = null, modifier = Modifier) }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(),
                )
            }
            item {
                Box {
                    AssistChip(
                        onClick = { sortMenu = true },
                        label = {
                            Text(
                                stringResource(
                                    when (filters.sort) {
                                        SortOrder.NAME -> R.string.sort_name
                                        SortOrder.COUNTRY -> R.string.sort_country
                                        SortOrder.CATEGORY -> R.string.sort_category
                                    }
                                )
                            )
                        },
                        trailingIcon = { Icon(Icons.Outlined.ArrowDropDown, contentDescription = null) },
                    )
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        listOf(
                            SortOrder.NAME to R.string.sort_name,
                            SortOrder.COUNTRY to R.string.sort_country,
                            SortOrder.CATEGORY to R.string.sort_category,
                        ).forEach { (order, label) ->
                            DropdownMenuItem(
                                text = { Text(stringResource(label)) },
                                onClick = { vm.update { it.copy(sort = order) }; sortMenu = false },
                            )
                        }
                    }
                }
            }
            if (filters.active) {
                item {
                    TextButton(onClick = vm::clearFilters) { Text(stringResource(R.string.clear_filters)) }
                }
            }
        }

        if (state.catalogLoading && state.catalogEmpty) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = Spacing.l))
        }

        LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = Spacing.xl)) {
            if (query.isBlank() && recentSearches.isNotEmpty()) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(start = Spacing.l, end = Spacing.s),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            stringResource(R.string.recent_searches),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { repo.prefs.clearRecentSearches() }) { Text(stringResource(R.string.clear)) }
                    }
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = Spacing.l),
                        horizontalArrangement = Arrangement.spacedBy(Spacing.s),
                    ) {
                        items(recentSearches) { s ->
                            AssistChip(
                                onClick = { vm.setQuery(s) },
                                label = { Text(s) },
                                leadingIcon = { Icon(Icons.Outlined.History, contentDescription = null) },
                            )
                        }
                    }
                }
            }

            if (state.ready) {
                item {
                    Text(
                        stringResource(R.string.results_count, state.results.size),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = Spacing.l, top = Spacing.m, bottom = Spacing.xs),
                    )
                }
            }

            if (state.ready && state.results.isEmpty() && !state.catalogLoading) {
                item {
                    EmptyState(
                        icon = Icons.Outlined.SearchOff,
                        title = stringResource(R.string.no_results_title),
                        message = stringResource(R.string.no_results_msg),
                        actionLabel = if (filters.active) stringResource(R.string.clear_filters) else null,
                        onAction = if (filters.active) vm::clearFilters else null,
                    )
                }
            }

            items(state.results, key = { it.id }) { channel ->
                ChannelRow(
                    channel = channel,
                    status = statuses[channel.id]?.status ?: ChannelStatus.UNKNOWN,
                    favorite = channel.id in favorites,
                    onClick = {
                        vm.commitSearch()
                        onPlay(channel, state.results)
                    },
                    onToggleFavorite = { repo.prefs.toggleFavorite(channel.id) },
                    onLongClick = { listSheetFor = channel },
                )
            }
        }
    }

    listSheetFor?.let { ch -> AddToListSheet(ch, onDismiss = { listSheetFor = null }) }

    // Selection sheets
    when (openSheet) {
        Sheet.COUNTRY -> {
            val locale = LocalConfiguration.current.locales[0]
            val options = remember(catalog, locale) {
                val collator = Collator.getInstance(locale)
                catalog.countries
                    .map { Triple(it.code, Countries.flag(it.code) + "  " + Countries.name(it.code, locale), it.count) }
                    .sortedWith { a, b -> collator.compare(a.second, b.second) }
            }
            OptionSheet(
                title = stringResource(R.string.filter_country),
                options = options,
                selected = filters.country,
                searchable = true,
                onSelect = { v -> vm.update { it.copy(country = v) }; openSheet = null },
                onDismiss = { openSheet = null },
            )
        }
        Sheet.CATEGORY -> {
            val options = catalog.categories.map { Triple(it.key, categoryLabel(it.key), it.count) }
            OptionSheet(
                title = stringResource(R.string.filter_category),
                options = options,
                selected = filters.category,
                searchable = false,
                onSelect = { v -> vm.update { it.copy(category = v) }; openSheet = null },
                onDismiss = { openSheet = null },
            )
        }
        Sheet.LANGUAGE -> {
            val options = catalog.languages.map { Triple(it, it, -1) }
            OptionSheet(
                title = stringResource(R.string.filter_language),
                options = options,
                selected = filters.language,
                searchable = true,
                onSelect = { v -> vm.update { it.copy(language = v) }; openSheet = null },
                onDismiss = { openSheet = null },
            )
        }
        null -> Unit
    }
}

/** options: (value, label, count or -1). Selecting "All" passes null. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OptionSheet(
    title: String,
    options: List<Triple<String, String, Int>>,
    selected: String?,
    searchable: Boolean,
    onSelect: (String?) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var filter by remember { mutableStateOf("") }
    val shown = remember(options, filter) {
        val tokens = com.ayman.worldtv.data.TextNormalizer.tokens(filter)
        if (tokens.isEmpty()) options
        else options.filter { o ->
            val key = com.ayman.worldtv.data.TextNormalizer.normalize(o.second + " " + o.first)
            tokens.all { key.contains(it) }
        }
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = Spacing.l))
        if (searchable) {
            OutlinedTextField(
                value = filter,
                onValueChange = { filter = it },
                modifier = Modifier.fillMaxWidth().padding(Spacing.l),
                placeholder = { Text(stringResource(R.string.search)) },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
                shape = CircleShape,
            )
        } else {
            Spacer(Modifier.height(Spacing.s))
        }
        LazyColumn(Modifier.fillMaxWidth().height(480.dp)) {
            item {
                OptionRow(stringResource(R.string.all), -1, selected == null) { onSelect(null) }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
            items(shown, key = { it.first }) { (value, label, count) ->
                OptionRow(label, count, selected == value) { onSelect(value) }
            }
        }
    }
}


@Composable
private fun OptionRow(label: String, count: Int, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.small) {
        Row(Modifier.fillMaxWidth().padding(horizontal = Spacing.s), verticalAlignment = Alignment.CenterVertically) {
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (count >= 0) {
                Text(
                    count.toString(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (selected) {
                Spacer(Modifier.padding(start = Spacing.s))
                Icon(Icons.Outlined.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
