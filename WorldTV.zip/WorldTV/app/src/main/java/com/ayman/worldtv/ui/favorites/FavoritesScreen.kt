package com.ayman.worldtv.ui.favorites

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material.icons.automirrored.outlined.PlaylistPlay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.model.ChannelStatus
import com.ayman.worldtv.ui.components.AddToListSheet
import com.ayman.worldtv.ui.components.ChannelRow
import com.ayman.worldtv.ui.components.EmptyState
import com.ayman.worldtv.ui.components.ScreenTitle
import com.ayman.worldtv.ui.theme.Spacing

private const val FAVORITES_KEY = "__favorites__"

@Composable
fun FavoritesScreen(onPlay: (Channel, List<Channel>) -> Unit, onExplore: () -> Unit) {
    val repo = LocalContext.current.app.repository
    val prefs = repo.prefs
    val catalog by repo.catalog.collectAsStateWithLifecycle()
    val favoriteIds by prefs.favorites.collectAsStateWithLifecycle()
    val statuses by prefs.statuses.collectAsStateWithLifecycle()
    val lists by prefs.lists.collectAsStateWithLifecycle()
    val progress by repo.checkProgress.collectAsStateWithLifecycle()

    var selected by rememberSaveable { mutableStateOf(FAVORITES_KEY) }
    var editing by rememberSaveable { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var listSheetFor by remember { mutableStateOf<Channel?>(null) }

    val currentList = lists.firstOrNull { it.id == selected }
    if (selected != FAVORITES_KEY && currentList == null) selected = FAVORITES_KEY

    val channels: List<Channel> = remember(catalog, favoriteIds, currentList, selected) {
        if (currentList == null) catalog.channels.filter { it.id in favoriteIds }
        else currentList.channelIds.mapNotNull { catalog.byId[it] }
    }
    val savedIds = currentList?.channelIds ?: favoriteIds.toList()
    val missing = if (catalog.loading || catalog.channels.isEmpty()) 0 else savedIds.count { it !in catalog.byId }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle(stringResource(R.string.nav_favorites))

        LazyRow(
            contentPadding = PaddingValues(horizontal = Spacing.l, vertical = Spacing.xs),
            horizontalArrangement = Arrangement.spacedBy(Spacing.s),
        ) {
            item {
                FilterChip(
                    selected = selected == FAVORITES_KEY,
                    onClick = { selected = FAVORITES_KEY; editing = false },
                    label = { Text(stringResource(R.string.nav_favorites)) },
                    leadingIcon = { Icon(Icons.Outlined.Favorite, contentDescription = null, modifier = Modifier.size(18.dp)) },
                )
            }
            items(lists, key = { it.id }) { list ->
                FilterChip(
                    selected = selected == list.id,
                    onClick = { selected = list.id; editing = false },
                    label = { Text(list.name) },
                    leadingIcon = { Icon(Icons.AutoMirrored.Outlined.PlaylistPlay, contentDescription = null, modifier = Modifier.size(18.dp)) },
                )
            }
            item {
                AssistChip(
                    onClick = { showCreate = true },
                    label = { Text(stringResource(R.string.new_list)) },
                    leadingIcon = { Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp)) },
                )
            }
        }

        // Action bar: link check + edit
        Row(
            Modifier.fillMaxWidth().padding(start = Spacing.s, end = Spacing.s),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val p = progress
            if (p != null) {
                Spacer(Modifier.width(Spacing.s))
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(Spacing.s))
                Text(
                    stringResource(R.string.checking, p.done, p.total),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                TextButton(
                    onClick = { repo.checkChannels(channels.map { it.id }) },
                    enabled = channels.isNotEmpty(),
                ) {
                    Icon(Icons.Outlined.NetworkCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(Spacing.xs))
                    Text(stringResource(R.string.check_links))
                }
            }
            Spacer(Modifier.weight(1f))
            if (currentList != null) {
                if (editing) {
                    TextButton(onClick = { prefs.deleteList(currentList.id); editing = false }) {
                        Text(stringResource(R.string.delete_list), color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = { editing = !editing }) {
                    Text(stringResource(if (editing) R.string.done else R.string.edit))
                }
            }
        }
        Text(
            stringResource(R.string.check_note),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = Spacing.l),
        )

        if (channels.isEmpty()) {
            if (currentList == null) {
                EmptyState(
                    icon = Icons.Outlined.FavoriteBorder,
                    title = stringResource(R.string.no_favorites_title),
                    message = stringResource(R.string.no_favorites_msg),
                    actionLabel = stringResource(R.string.nav_explore),
                    onAction = onExplore,
                )
            } else {
                EmptyState(
                    icon = Icons.AutoMirrored.Outlined.PlaylistPlay,
                    title = stringResource(R.string.empty_list_title),
                    message = stringResource(R.string.empty_list_msg),
                    actionLabel = stringResource(R.string.nav_explore),
                    onAction = onExplore,
                )
            }
        }

        LazyColumn(contentPadding = PaddingValues(bottom = Spacing.xl)) {
            items(channels, key = { it.id }) { channel ->
                val listId = currentList?.id
                ChannelRow(
                    channel = channel,
                    status = statuses[channel.id]?.status ?: ChannelStatus.UNKNOWN,
                    favorite = channel.id in favoriteIds,
                    onClick = { if (!editing) onPlay(channel, channels) },
                    onToggleFavorite = { prefs.toggleFavorite(channel.id) },
                    onLongClick = { listSheetFor = channel },
                    trailing = if (editing && listId != null) {
                        {
                            Row {
                                IconButton(onClick = { prefs.moveInList(listId, channel.id, -1) }) {
                                    Icon(Icons.Outlined.KeyboardArrowUp, contentDescription = stringResource(R.string.move_up))
                                }
                                IconButton(onClick = { prefs.moveInList(listId, channel.id, 1) }) {
                                    Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = stringResource(R.string.move_down))
                                }
                                IconButton(onClick = { prefs.toggleInList(listId, channel.id) }) {
                                    Icon(Icons.Outlined.Close, contentDescription = stringResource(R.string.remove))
                                }
                            }
                        }
                    } else null,
                )
            }
            if (missing > 0) {
                item {
                    Text(
                        stringResource(R.string.favorites_missing, missing),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(Spacing.l),
                    )
                }
            }
        }
    }

    listSheetFor?.let { ch -> AddToListSheet(ch, onDismiss = { listSheetFor = null }) }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text(stringResource(R.string.new_list)) },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(stringResource(R.string.list_name)) },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val created = prefs.createList(name)
                        selected = created.id
                        showCreate = false
                    },
                    enabled = name.isNotBlank(),
                ) { Text(stringResource(R.string.create)) }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
