package com.ayman.worldtv.ui.favorites

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.model.ChannelStatus
import com.ayman.worldtv.ui.components.ChannelRow
import com.ayman.worldtv.ui.components.EmptyState
import com.ayman.worldtv.ui.components.ScreenTitle
import com.ayman.worldtv.ui.theme.Spacing

@Composable
fun FavoritesScreen(onPlay: (Channel, List<Channel>) -> Unit, onExplore: () -> Unit) {
    val repo = LocalContext.current.app.repository
    val catalog by repo.catalog.collectAsStateWithLifecycle()
    val favoriteIds by repo.prefs.favorites.collectAsStateWithLifecycle()
    val statuses by repo.prefs.statuses.collectAsStateWithLifecycle()

    val favorites = remember(catalog, favoriteIds) { catalog.channels.filter { it.id in favoriteIds } }
    val missing = if (catalog.loading || catalog.channels.isEmpty()) 0 else favoriteIds.count { it !in catalog.byId }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle(stringResource(R.string.nav_favorites))
        if (favorites.isEmpty()) {
            EmptyState(
                icon = Icons.Outlined.FavoriteBorder,
                title = stringResource(R.string.no_favorites_title),
                message = stringResource(R.string.no_favorites_msg),
                actionLabel = stringResource(R.string.nav_explore),
                onAction = onExplore,
            )
        }
        LazyColumn(contentPadding = PaddingValues(bottom = Spacing.xl)) {
            items(favorites, key = { it.id }) { channel ->
                ChannelRow(
                    channel = channel,
                    status = statuses[channel.id]?.status ?: ChannelStatus.UNKNOWN,
                    favorite = true,
                    onClick = { onPlay(channel, favorites) },
                    onToggleFavorite = { repo.prefs.toggleFavorite(channel.id) },
                )
            }
            if (missing > 0) {
                item {
                    Text(
                        stringResource(R.string.favorites_missing, missing),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(Spacing.l),
                    )
                }
            }
        }
    }
}
