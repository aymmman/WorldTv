package com.ayman.worldtv.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.format.DateUtils
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.worldtv.BuildConfig
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.data.Prefs
import com.ayman.worldtv.model.PlaylistSource
import com.ayman.worldtv.model.ThemeMode
import com.ayman.worldtv.ui.components.ScreenTitle
import com.ayman.worldtv.ui.theme.Spacing
import com.ayman.worldtv.ui.theme.WtvColors
import kotlinx.coroutines.launch

private data class Preset(val label: Int, val path: String)

private val presets = listOf(
    Preset(R.string.preset_arabic, "languages/ara.m3u"),
    Preset(R.string.preset_jordan, "countries/jo.m3u"),
    Preset(R.string.preset_iraq, "countries/iq.m3u"),
    Preset(R.string.preset_news, "categories/news.m3u"),
    Preset(R.string.preset_sports, "categories/sports.m3u"),
)

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val repo = context.app.repository
    val prefs = repo.prefs
    val settings by prefs.settings.collectAsStateWithLifecycle()
    val sources by prefs.sources.collectAsStateWithLifecycle()
    val catalog by repo.catalog.collectAsStateWithLifecycle()
    val todayBytes by prefs.todayBytes.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var showAddDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { prefs.refreshTodayBytes() }

    val doneMsg = stringResource(R.string.done)
    val importFailed = stringResource(R.string.import_failed)
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val count = repo.importLocalPlaylist(uri)
                val msg = if (count > 0) context.getString(R.string.imported, count) else importFailed
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(contentPadding = PaddingValues(bottom = Spacing.xxl)) {
        item { ScreenTitle(stringResource(R.string.nav_settings)) }

        // ---------- Playback ----------
        item { GroupTitle(stringResource(R.string.section_playback)) }
        item {
            SwitchRow(
                title = stringResource(R.string.wifi_only),
                subtitle = stringResource(R.string.wifi_only_desc),
                checked = settings.wifiOnly,
                onChange = { v -> prefs.updateSettings { it.copy(wifiOnly = v) } },
            )
        }
        item {
            SwitchRow(
                title = stringResource(R.string.warn_mobile),
                subtitle = stringResource(R.string.warn_mobile_desc),
                checked = settings.warnOnMobile,
                onChange = { v -> prefs.updateSettings { it.copy(warnOnMobile = v) } },
            )
        }

        // ---------- Data ----------
        item { GroupTitle(stringResource(R.string.section_data)) }
        item {
            Column(Modifier.padding(horizontal = Spacing.l)) {
                Text(
                    stringResource(R.string.data_today, Formatter.formatShortFileSize(context, todayBytes)),
                    style = MaterialTheme.typography.bodyLarge,
                )
                Text(
                    stringResource(R.string.data_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(Spacing.m))
                Text(stringResource(R.string.daily_warning), style = MaterialTheme.typography.labelLarge)
            }
        }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = Spacing.l, vertical = Spacing.s),
                horizontalArrangement = Arrangement.spacedBy(Spacing.s),
            ) {
                items(listOf(0, 500, 1000, 2000, 5000)) { mb ->
                    FilterChip(
                        selected = settings.dailyWarningMb == mb,
                        onClick = { prefs.updateSettings { it.copy(dailyWarningMb = mb) } },
                        label = {
                            Text(
                                when {
                                    mb == 0 -> stringResource(R.string.off)
                                    mb >= 1000 -> "${mb / 1000} GB"
                                    else -> "$mb MB"
                                }
                            )
                        },
                    )
                }
            }
        }

        // ---------- Sources ----------
        item { GroupTitle(stringResource(R.string.section_sources)) }
        item {
            Text(
                stringResource(R.string.sources_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = Spacing.l),
            )
        }
        items(sources, key = { it.id }) { source ->
            SourceRow(
                source = source,
                onToggle = { repo.setSourceEnabled(source, it) },
                onDelete = { repo.removeSource(source) },
            )
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = Spacing.l, vertical = Spacing.s),
                horizontalArrangement = Arrangement.spacedBy(Spacing.s),
            ) {
                OutlinedButton(onClick = { showAddDialog = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(Spacing.xs))
                    Text(stringResource(R.string.add_url), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(Spacing.xs))
                    Text(stringResource(R.string.import_file), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        item {
            Text(
                stringResource(R.string.quick_add),
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(start = Spacing.l, top = Spacing.s),
            )
        }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = Spacing.l, vertical = Spacing.s),
                horizontalArrangement = Arrangement.spacedBy(Spacing.s),
            ) {
                items(presets) { preset ->
                    val url = "${Prefs.IPTV_ORG_BASE}/${preset.path}"
                    val added = sources.any { it.url == url }
                    val label = stringResource(preset.label)
                    AssistChip(
                        onClick = { repo.addUrlSource("iptv-org: $label", url) },
                        enabled = !added,
                        label = { Text(label) },
                        leadingIcon = { Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    )
                }
            }
        }
        item {
            ActionRow(
                icon = Icons.Outlined.Refresh,
                title = stringResource(R.string.refresh_now),
                subtitle = stringResource(
                    R.string.updated_at,
                    if (catalog.lastUpdated > 0) DateUtils.getRelativeTimeSpanString(catalog.lastUpdated).toString()
                    else stringResource(R.string.never)
                ),
                loading = catalog.loading,
                onClick = { repo.refreshAsync() },
            )
        }
        if (catalog.sourceErrors.isNotEmpty() && !catalog.loading) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.padding(horizontal = Spacing.l).fillMaxWidth(),
                ) {
                    Column(Modifier.padding(Spacing.m)) {
                        Text(stringResource(R.string.source_errors), style = MaterialTheme.typography.labelLarge, color = WtvColors.Warning)
                        catalog.sourceErrors.forEach {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // ---------- Appearance ----------
        item { GroupTitle(stringResource(R.string.section_appearance)) }
        item {
            Row(
                Modifier.padding(horizontal = Spacing.l),
                horizontalArrangement = Arrangement.spacedBy(Spacing.s),
            ) {
                listOf(
                    ThemeMode.DARK to R.string.theme_dark,
                    ThemeMode.LIGHT to R.string.theme_light,
                    ThemeMode.SYSTEM to R.string.theme_system,
                ).forEach { (mode, label) ->
                    FilterChip(
                        selected = settings.theme == mode,
                        onClick = { prefs.updateSettings { it.copy(theme = mode) } },
                        label = { Text(stringResource(label)) },
                    )
                }
            }
        }
        item {
            val canPick = Build.VERSION.SDK_INT >= 33
            ActionRow(
                icon = Icons.Outlined.Language,
                title = stringResource(R.string.app_language),
                subtitle = stringResource(if (canPick) R.string.app_language_desc else R.string.app_language_old),
                onClick = if (canPick) {
                    {
                        val intent = Intent(Settings.ACTION_APP_LOCALE_SETTINGS)
                            .setData(Uri.fromParts("package", context.packageName, null))
                        runCatching { context.startActivity(intent) }
                        Unit
                    }
                } else null,
            )
        }

        // ---------- Privacy ----------
        item { GroupTitle(stringResource(R.string.section_privacy)) }
        item {
            Text(
                stringResource(R.string.privacy_text),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = Spacing.l),
            )
        }
        item {
            Column(Modifier.padding(horizontal = Spacing.s)) {
                TextButton(onClick = { prefs.clearHistory(); Toast.makeText(context, doneMsg, Toast.LENGTH_SHORT).show() }) {
                    Text(stringResource(R.string.clear_history))
                }
                TextButton(onClick = { prefs.clearRecentSearches(); Toast.makeText(context, doneMsg, Toast.LENGTH_SHORT).show() }) {
                    Text(stringResource(R.string.clear_searches))
                }
                TextButton(onClick = { prefs.clearStatuses(); Toast.makeText(context, doneMsg, Toast.LENGTH_SHORT).show() }) {
                    Text(stringResource(R.string.clear_status))
                }
            }
        }

        // ---------- About ----------
        item { GroupTitle(stringResource(R.string.section_about)) }
        item {
            Column(Modifier.padding(horizontal = Spacing.l)) {
                Text(
                    stringResource(R.string.about_text),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(Spacing.s))
                Text(
                    stringResource(R.string.version, BuildConfig.VERSION_NAME),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    if (showAddDialog) {
        AddSourceDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { name, url ->
                repo.addUrlSource(name, url)
                showAddDialog = false
            },
        )
    }
}

@Composable
private fun GroupTitle(text: String) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = Spacing.l, end = Spacing.l, top = Spacing.xl, bottom = Spacing.s),
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = Spacing.l, vertical = Spacing.s),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(Spacing.m))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    loading: Boolean = false,
    onClick: (() -> Unit)?,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (onClick != null && !loading) it.clickable(onClick = onClick) else it }
            .padding(horizontal = Spacing.l, vertical = Spacing.m),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
        } else {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.width(Spacing.l))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SourceRow(source: PlaylistSource, onToggle: (Boolean) -> Unit, onDelete: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().padding(start = Spacing.l, end = Spacing.xs, top = Spacing.s, bottom = Spacing.s),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                if (source.isLocal) Icons.Outlined.UploadFile else Icons.Outlined.Link,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(Spacing.m))
            Column(Modifier.weight(1f)) {
                Text(source.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (!source.isLocal) {
                    Text(
                        source.url,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Switch(checked = source.enabled, onCheckedChange = onToggle)
            if (!source.builtIn) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Outlined.Delete, contentDescription = stringResource(R.string.delete))
                }
            } else {
                Spacer(Modifier.width(Spacing.m))
            }
        }
        HorizontalDivider(Modifier.padding(start = 56.dp), color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
private fun AddSourceDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_url)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(Spacing.s)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(stringResource(R.string.source_name)) },
                    singleLine = true,
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; error = false },
                    label = { Text(stringResource(R.string.source_url)) },
                    singleLine = true,
                    isError = error,
                    supportingText = if (error) {
                        { Text(stringResource(R.string.invalid_url)) }
                    } else null,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val trimmed = url.trim()
                val parsed = runCatching { Uri.parse(trimmed) }.getOrNull()
                val valid = parsed != null &&
                    (parsed.scheme == "http" || parsed.scheme == "https") &&
                    !parsed.host.isNullOrBlank()
                if (valid) onAdd(name.trim(), trimmed) else error = true
            }) { Text(stringResource(R.string.add)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
