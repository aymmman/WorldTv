package com.ayman.worldtv.util

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.ChildCare
import androidx.compose.material.icons.outlined.Landscape
import androidx.compose.material.icons.outlined.LiveTv
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.SportsSoccer
import androidx.compose.material.icons.outlined.TheaterComedy
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import com.ayman.worldtv.R

object Categories {
    val featured = listOf(
        "news", "sports", "entertainment", "movies", "kids",
        "music", "documentary", "education", "religious", "general",
    )

    /** Arabic words added to the search index so "اخبار" finds news channels. */
    val arabicSynonyms = mapOf(
        "news" to "اخبار اخباريه",
        "sports" to "رياضه رياضيه",
        "entertainment" to "ترفيه منوعات",
        "movies" to "افلام سينما",
        "kids" to "اطفال كرتون",
        "music" to "موسيقي اغاني",
        "documentary" to "وثائقي",
        "education" to "تعليم تعليميه",
        "religious" to "ديني دينيه اسلامي قران",
        "general" to "عام عامه",
        "series" to "مسلسلات",
        "business" to "اقتصاد",
        "cooking" to "طبخ",
        "comedy" to "كوميديا",
        "animation" to "رسوم متحركه كرتون",
    )

    fun icon(key: String): ImageVector = when (key) {
        "news" -> Icons.Outlined.Newspaper
        "sports" -> Icons.Outlined.SportsSoccer
        "entertainment", "comedy" -> Icons.Outlined.TheaterComedy
        "movies", "series" -> Icons.Outlined.Movie
        "kids", "animation", "family" -> Icons.Outlined.ChildCare
        "music" -> Icons.Outlined.MusicNote
        "documentary", "travel" -> Icons.Outlined.Landscape
        "education" -> Icons.Outlined.School
        "religious" -> Icons.Outlined.AutoStories
        else -> Icons.Outlined.LiveTv
    }

    @StringRes
    fun labelRes(key: String): Int? = when (key) {
        "news" -> R.string.cat_news
        "sports" -> R.string.cat_sports
        "entertainment" -> R.string.cat_entertainment
        "movies" -> R.string.cat_movies
        "kids" -> R.string.cat_kids
        "music" -> R.string.cat_music
        "documentary" -> R.string.cat_documentary
        "education" -> R.string.cat_education
        "religious" -> R.string.cat_religious
        "general" -> R.string.cat_general
        "series" -> R.string.cat_series
        "business" -> R.string.cat_business
        "culture" -> R.string.cat_culture
        "lifestyle" -> R.string.cat_lifestyle
        "cooking" -> R.string.cat_cooking
        "travel" -> R.string.cat_travel
        "comedy" -> R.string.cat_comedy
        "animation" -> R.string.cat_animation
        "family" -> R.string.cat_family
        "undefined" -> R.string.cat_other
        else -> null
    }
}

@Composable
fun categoryLabel(key: String): String {
    val res = Categories.labelRes(key)
    return if (res != null) stringResource(res) else key.replaceFirstChar { it.titlecase() }
}
