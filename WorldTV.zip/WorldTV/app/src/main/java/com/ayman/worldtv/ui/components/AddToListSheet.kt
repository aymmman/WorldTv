package com.ayman.worldtv.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.ui.theme.Spacing

/** Bottom sheet to put a channel in favorites and in the user's own lists. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddToListSheet(channel: Channel, onDismiss: () -> Unit) {
    val prefs = LocalContext.current.app.prefs
    val lists by prefs.lists.collectAsStateWithLifecycle()
    val favorites by prefs.favorites.collectAsStateWithLifecycle()
    var newName by remember { mutableStateOf("") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.navigationBarsPadding().padding(bottom = Spacing.l)) {
            Row(Modifier.padding(horizontal = Spacing.l), verticalAlignment = Alignment.CenterVertically) {
                ChannelLogo(channel.logo, channel.name, size = 40.dp)
                Spacer(Modifier.width(Spacing.m))
                Text(
                    channel.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(Spacing.m))
            val isFav = channel.id in favorites
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { prefs.toggleFavorite(channel.id) }
                    .padding(horizontal = Spacing.l, vertical = Spacing.m),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    if (isFav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                )
                Spacer(Modifier.width(Spacing.m))
                Text(stringResource(R.string.nav_favorites), style = MaterialTheme.typography.bodyLarge)
            }
            LazyColumn(Modifier.heightIn(max = 320.dp)) {
                items(lists, key = { it.id }) { list ->
                    val inList = channel.id in list.channelIds
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { prefs.toggleInList(list.id, channel.id) }
                            .padding(horizontal = Spacing.s),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = inList, onCheckedChange = { prefs.toggleInList(list.id, channel.id) })
                        Text(list.name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                        Text(
                            list.channelIds.size.toString(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = Spacing.m),
                        )
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = Spacing.l, vertical = Spacing.s),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(stringResource(R.string.new_list)) },
                    singleLine = true,
                )
                TextButton(
                    onClick = {
                        val created = prefs.createList(newName)
                        prefs.toggleInList(created.id, channel.id)
                        newName = ""
                    },
                    enabled = newName.isNotBlank(),
                ) { Text(stringResource(R.string.create)) }
            }
        }
    }
}
