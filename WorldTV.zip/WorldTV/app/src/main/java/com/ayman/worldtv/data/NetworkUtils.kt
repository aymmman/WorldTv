package com.ayman.worldtv.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

enum class NetType { NONE, UNMETERED, METERED }

object NetworkUtils {
    fun current(context: Context): NetType {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return NetType.NONE
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return NetType.NONE
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return NetType.NONE
        val unmetered = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        return if (unmetered) NetType.UNMETERED else NetType.METERED
    }
}
