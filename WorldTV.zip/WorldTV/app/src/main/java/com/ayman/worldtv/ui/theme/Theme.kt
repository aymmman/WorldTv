package com.ayman.worldtv.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Design tokens for World TV. */
object Spacing {
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
}

object WtvColors {
    val Cyan = Color(0xFF22D3EE)
    val CyanDeep = Color(0xFF0891B2)
    val Midnight = Color(0xFF070B14)
    val Navy = Color(0xFF0C1322)
    val Success = Color(0xFF34D399)
    val Warning = Color(0xFFFBBF24)
    val Live = Color(0xFFEF4444)
}

private val DarkScheme = darkColorScheme(
    primary = WtvColors.Cyan,
    onPrimary = Color(0xFF02141A),
    primaryContainer = Color(0xFF0E3A47),
    onPrimaryContainer = Color(0xFFBFF4FD),
    secondary = Color(0xFF7DD3FC),
    onSecondary = Color(0xFF04202E),
    secondaryContainer = Color(0xFF13304A),
    onSecondaryContainer = Color(0xFFCDEBFF),
    background = WtvColors.Midnight,
    onBackground = Color(0xFFF1F5FB),
    surface = WtvColors.Midnight,
    onSurface = Color(0xFFF1F5FB),
    surfaceVariant = Color(0xFF152038),
    onSurfaceVariant = Color(0xFF94A3BF),
    surfaceContainerLowest = Color(0xFF05080F),
    surfaceContainerLow = Color(0xFF0A111E),
    surfaceContainer = WtvColors.Navy,
    surfaceContainerHigh = Color(0xFF131C30),
    surfaceContainerHighest = Color(0xFF1A2540),
    outline = Color(0xFF2A3654),
    outlineVariant = Color(0xFF1C2742),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF2B0505),
)

private val LightScheme = lightColorScheme(
    primary = WtvColors.CyanDeep,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCFF5FC),
    onPrimaryContainer = Color(0xFF053340),
    secondary = Color(0xFF0369A1),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDF0FF),
    onSecondaryContainer = Color(0xFF062A40),
    background = Color(0xFFF6F8FC),
    onBackground = Color(0xFF0B1220),
    surface = Color(0xFFF6F8FC),
    onSurface = Color(0xFF0B1220),
    surfaceVariant = Color(0xFFE6EBF3),
    onSurfaceVariant = Color(0xFF55607A),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF9FAFD),
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFEEF2F8),
    surfaceContainerHighest = Color(0xFFE4E9F2),
    outline = Color(0xFFC5CCDA),
    outlineVariant = Color(0xFFDDE2EC),
    error = Color(0xFFD32F2F),
    onError = Color.White,
)

private val WtvShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

private val base = Typography()
private val WtvTypography = base.copy(
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    titleSmall = base.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp),
)

@Composable
fun WorldTvTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        typography = WtvTypography,
        shapes = WtvShapes,
        content = content,
    )
}
