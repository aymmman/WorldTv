package com.ayman.worldtv.ui

import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.ayman.worldtv.R
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.player.PlayerActivity
import com.ayman.worldtv.ui.countries.CountriesScreen
import com.ayman.worldtv.ui.explore.ExploreScreen
import com.ayman.worldtv.ui.favorites.FavoritesScreen
import com.ayman.worldtv.ui.home.HomeScreen
import com.ayman.worldtv.ui.settings.SettingsScreen

private data class Tab(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector,
    val selectedIcon: ImageVector,
)

private val tabs = listOf(
    Tab("home", R.string.nav_home, Icons.Outlined.Home, Icons.Filled.Home),
    Tab("explore", R.string.nav_explore, Icons.Outlined.Search, Icons.Filled.Search),
    Tab("countries", R.string.nav_countries, Icons.Outlined.Public, Icons.Filled.Public),
    Tab("favorites", R.string.nav_favorites, Icons.Outlined.FavoriteBorder, Icons.Filled.Favorite),
    Tab("settings", R.string.nav_settings, Icons.Outlined.Settings, Icons.Filled.Settings),
)

private fun NavHostController.switchTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun WorldTvRoot() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route?.substringBefore('?').orEmpty()
    val context = LocalContext.current
    val play: (Channel, List<Channel>) -> Unit = { channel, queue -> PlayerActivity.start(context, channel, queue) }

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                tabs.forEach { tab ->
                    val selected = currentRoute == tab.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = { nav.switchTab(tab.route) },
                        icon = { Icon(if (selected) tab.selectedIcon else tab.icon, contentDescription = null) },
                        label = { Text(stringResource(tab.label), maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") {
                HomeScreen(
                    onSearch = { nav.navigate("explore?focus=true") },
                    onCategory = { nav.navigate("explore?category=" + Uri.encode(it)) },
                    onCountry = { nav.navigate("explore?country=" + Uri.encode(it)) },
                    onAllCountries = { nav.switchTab("countries") },
                    onFavorites = { nav.switchTab("favorites") },
                    onSettings = { nav.switchTab("settings") },
                    onPlay = play,
                )
            }
            composable(
                "explore?country={country}&category={category}&focus={focus}",
                arguments = listOf(
                    navArgument("country") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("category") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("focus") { type = NavType.BoolType; defaultValue = false },
                ),
            ) { entry ->
                ExploreScreen(
                    initialCountry = entry.arguments?.getString("country"),
                    initialCategory = entry.arguments?.getString("category"),
                    autoFocus = entry.arguments?.getBoolean("focus") ?: false,
                    onPlay = play,
                )
            }
            composable("countries") {
                CountriesScreen(onCountry = { nav.navigate("explore?country=" + Uri.encode(it)) })
            }
            composable("favorites") {
                FavoritesScreen(onPlay = play, onExplore = { nav.switchTab("explore") })
            }
            composable("settings") {
                SettingsScreen()
            }
        }
    }
}
