package com.ayman.worldtv.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.data.Prefs
import com.ayman.worldtv.data.TextNormalizer
import com.ayman.worldtv.util.Categories
import com.ayman.worldtv.util.Countries
import com.ayman.worldtv.util.categoryLabel
import java.text.Collator
import java.util.Locale

private enum class DiscoverTab { COUNTRIES, LANGUAGES, CATEGORIES }

private data class DiscoverItem(val label: String, val path: String, val searchKey: String)

/** iptv-org language playlists use ISO 639-3 codes; the 2-letter code is only for display names. */
private val languageCodes = listOf(
    "ara" to "ar", "eng" to "en", "fra" to "fr", "spa" to "es", "deu" to "de", "tur" to "tr",
    "fas" to "fa", "kur" to "ku", "urd" to "ur", "hin" to "hi", "ben" to "bn", "rus" to "ru",
    "por" to "pt", "ita" to "it", "nld" to "nl", "ell" to "el", "pol" to "pl", "ukr" to "uk",
    "heb" to "he", "zho" to "zh", "jpn" to "ja", "kor" to "ko", "ind" to "id", "msa" to "ms",
    "swa" to "sw", "som" to "so", "amh" to "am", "aze" to "az", "uzb" to "uz", "kaz" to "kk",
)

private val categoryKeys = listOf(
    "news", "sports", "entertainment", "movies", "series", "kids", "animation", "music",
    "documentary", "education", "religious", "general", "business", "culture", "lifestyle",
    "cooking", "travel", "comedy", "family", "science", "weather", "classic", "outdoor", "auto",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverSheet(onDismiss: () -> Unit) {
    val repo = LocalContext.current.app.repository
    val sources by repo.prefs.sources.collectAsStateWithLifecycle()
    val locale = LocalConfiguration.current.locales[0]
    var tab by remember { mutableStateOf(DiscoverTab.COUNTRIES) }
    var query by remember { mutableStateOf("") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val arabWorld = stringResource(R.string.region_arab)

    val countries = remember(locale, arabWorld) {
        val collator = Collator.getInstance(locale)
        val list = Locale.getISOCountries().map { code ->
            val path = "countries/" + (if (code == "GB") "uk" else code.lowercase()) + ".m3u"
            DiscoverItem(
                label = Countries.flag(code) + "  " + Countries.name(code, locale),
                path = path,
                searchKey = TextNormalizer.normalize(
                    Countries.name(code, locale) + " " + Countries.name(code, Locale.ENGLISH) + " " +
                        Countries.name(code, Countries.ARABIC) + " " + code
                ),
            )
        }.sortedWith { a, b -> collator.compare(a.label.substringAfter("  "), b.label.substringAfter("  ")) }
        listOf(DiscoverItem("\uD83C\uDF0D  $arabWorld", "regions/arab.m3u", TextNormalizer.normalize("$arabWorld arab عرب"))) + list
    }
    val languages = remember(locale) {
        languageCodes.map { (iso3, iso2) ->
            val name = Locale(iso2).getDisplayLanguage(locale).replaceFirstChar { it.titlecase(locale) }
            DiscoverItem(
                label = name,
                path = "languages/$iso3.m3u",
                searchKey = TextNormalizer.normalize(
                    name + " " + Locale(iso2).getDisplayLanguage(Locale.ENGLISH) + " " +
                        Locale(iso2).getDisplayLanguage(Countries.ARABIC) + " " + iso3
                ),
            )
        }
    }
    val categoryItems = categoryKeys.map { key ->
        val label = categoryLabel(key)
        DiscoverItem(
            label = label,
            path = "categories/$key.m3u",
            searchKey = TextNormalizer.normalize(label + " " + key + " " + (Categories.arabicSynonyms[key] ?: "")),
        )
    }

    val all = when (tab) {
        DiscoverTab.COUNTRIES -> countries
        DiscoverTab.LANGUAGES -> languages
        DiscoverTab.CATEGORIES -> categoryItems
    }
    val tokens = TextNormalizer.tokens(query)
    val shown = if (tokens.isEmpty()) all else all.filter { item -> tokens.all { item.searchKey.contains(it) } }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column {
            Text(
                stringResource(R.string.discover_title),
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Text(
                stringResource(R.string.discover_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    FilterChip(
                        selected = tab == DiscoverTab.COUNTRIES,
                        onClick = { tab = DiscoverTab.COUNTRIES },
                        label = { Text(stringResource(R.string.nav_countries)) },
                    )
                }
                item {
                    FilterChip(
                        selected = tab == DiscoverTab.LANGUAGES,
                        onClick = { tab = DiscoverTab.LANGUAGES },
                        label = { Text(stringResource(R.string.languages)) },
                    )
                }
                item {
                    FilterChip(
                        selected = tab == DiscoverTab.CATEGORIES,
                        onClick = { tab = DiscoverTab.CATEGORIES },
                        label = { Text(stringResource(R.string.categories)) },
                    )
                }
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                placeholder = { Text(stringResource(R.string.search)) },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
                shape = CircleShape,
            )
            LazyColumn(Modifier.fillMaxWidth().height(460.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                items(shown, key = { it.path }) { item ->
                    val url = "${Prefs.IPTV_ORG_BASE}/${item.path}"
                    val added = sources.any { it.url == url }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !added) { repo.addUrlSource("iptv-org: " + item.label.trim(), url) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            item.label,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Icon(
                            if (added) Icons.Outlined.CheckCircle else Icons.Outlined.Add,
                            contentDescription = stringResource(if (added) R.string.added else R.string.add),
                            tint = if (added) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}
