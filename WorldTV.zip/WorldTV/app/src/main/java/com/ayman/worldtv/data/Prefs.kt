package com.ayman.worldtv.data

import android.content.Context
import com.ayman.worldtv.model.AppSettings
import com.ayman.worldtv.model.ChannelStatus
import com.ayman.worldtv.model.HistoryEntry
import com.ayman.worldtv.model.PlaylistSource
import com.ayman.worldtv.model.StatusRecord
import com.ayman.worldtv.model.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** All user data lives here, on the device only. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("worldtv_prefs", Context.MODE_PRIVATE)

    private val _favorites = MutableStateFlow(sp.getStringSet(K_FAV, null)?.toSet() ?: emptySet())
    val favorites: StateFlow<Set<String>> = _favorites.asStateFlow()

    private val _history = MutableStateFlow(readHistory())
    val history: StateFlow<List<HistoryEntry>> = _history.asStateFlow()

    private val _statuses = MutableStateFlow(readStatuses())
    val statuses: StateFlow<Map<String, StatusRecord>> = _statuses.asStateFlow()

    private val _sources = MutableStateFlow(readSources())
    val sources: StateFlow<List<PlaylistSource>> = _sources.asStateFlow()

    private val _settings = MutableStateFlow(readSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _recentSearches = MutableStateFlow(readStringList(K_SEARCHES))
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    private val _todayBytes = MutableStateFlow(readTodayBytes())
    val todayBytes: StateFlow<Long> = _todayBytes.asStateFlow()

    var lastRefresh: Long
        get() = sp.getLong(K_LAST_REFRESH, 0L)
        set(value) = sp.edit().putLong(K_LAST_REFRESH, value).apply()

    // ---------- Favorites ----------
    @Synchronized
    fun toggleFavorite(id: String) {
        val next = _favorites.value.toMutableSet()
        if (!next.add(id)) next.remove(id)
        _favorites.value = next
        sp.edit().putStringSet(K_FAV, next).apply()
    }

    // ---------- History ----------
    @Synchronized
    fun addHistory(id: String) {
        val next = (listOf(HistoryEntry(id, System.currentTimeMillis())) +
            _history.value.filter { it.channelId != id }).take(40)
        _history.value = next
        val arr = JSONArray()
        next.forEach { arr.put(JSONObject().put("id", it.channelId).put("t", it.time)) }
        sp.edit().putString(K_HISTORY, arr.toString()).apply()
    }

    fun clearHistory() {
        _history.value = emptyList()
        sp.edit().remove(K_HISTORY).apply()
    }

    private fun readHistory(): List<HistoryEntry> = try {
        val arr = JSONArray(sp.getString(K_HISTORY, "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryEntry(o.getString("id"), o.optLong("t"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    // ---------- Channel status ----------
    @Synchronized
    fun setStatus(id: String, status: ChannelStatus) {
        val next = LinkedHashMap(_statuses.value)
        next.remove(id)
        next[id] = StatusRecord(status, System.currentTimeMillis())
        while (next.size > 3000) next.remove(next.keys.first())
        _statuses.value = next
        val obj = JSONObject()
        next.forEach { (k, v) -> obj.put(k, JSONObject().put("s", v.status.name).put("t", v.time)) }
        sp.edit().putString(K_STATUS, obj.toString()).apply()
    }

    fun clearStatuses() {
        _statuses.value = emptyMap()
        sp.edit().remove(K_STATUS).apply()
    }

    private fun readStatuses(): Map<String, StatusRecord> = try {
        val obj = JSONObject(sp.getString(K_STATUS, "{}") ?: "{}")
        val map = LinkedHashMap<String, StatusRecord>()
        obj.keys().forEach { k ->
            val o = obj.getJSONObject(k)
            map[k] = StatusRecord(ChannelStatus.valueOf(o.getString("s")), o.optLong("t"))
        }
        map
    } catch (e: Exception) {
        emptyMap()
    }

    // ---------- Sources ----------
    @Synchronized
    fun addSource(name: String, url: String): PlaylistSource {
        val src = PlaylistSource(UUID.randomUUID().toString().take(8), name, url, enabled = true, builtIn = false)
        saveSources(_sources.value + src)
        return src
    }

    @Synchronized
    fun removeSource(id: String) = saveSources(_sources.value.filterNot { it.id == id })

    @Synchronized
    fun setSourceEnabled(id: String, enabled: Boolean) =
        saveSources(_sources.value.map { if (it.id == id) it.copy(enabled = enabled) else it })

    private fun saveSources(list: List<PlaylistSource>) {
        _sources.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)
                    .put("enabled", it.enabled).put("builtIn", it.builtIn)
            )
        }
        sp.edit().putString(K_SOURCES, arr.toString()).apply()
    }

    private fun readSources(): List<PlaylistSource> {
        val raw = sp.getString(K_SOURCES, null) ?: return DEFAULT_SOURCES
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                PlaylistSource(
                    o.getString("id"), o.getString("name"), o.getString("url"),
                    o.optBoolean("enabled", true), o.optBoolean("builtIn", false)
                )
            }
        } catch (e: Exception) {
            DEFAULT_SOURCES
        }
    }

    // ---------- Settings ----------
    @Synchronized
    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val next = transform(_settings.value)
        _settings.value = next
        sp.edit()
            .putBoolean(K_WIFI_ONLY, next.wifiOnly)
            .putBoolean(K_WARN_MOBILE, next.warnOnMobile)
            .putString(K_THEME, next.theme.name)
            .putInt(K_DAILY_WARN, next.dailyWarningMb)
            .apply()
    }

    private fun readSettings() = AppSettings(
        wifiOnly = sp.getBoolean(K_WIFI_ONLY, false),
        warnOnMobile = sp.getBoolean(K_WARN_MOBILE, true),
        theme = runCatching { ThemeMode.valueOf(sp.getString(K_THEME, ThemeMode.DARK.name)!!) }
            .getOrDefault(ThemeMode.DARK),
        dailyWarningMb = sp.getInt(K_DAILY_WARN, 0),
    )

    // ---------- Recent searches ----------
    @Synchronized
    fun addRecentSearch(query: String) {
        val q = query.trim()
        if (q.length < 2) return
        val next = (listOf(q) + _recentSearches.value.filterNot { it.equals(q, ignoreCase = true) }).take(10)
        _recentSearches.value = next
        sp.edit().putString(K_SEARCHES, JSONArray(next).toString()).apply()
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        sp.edit().remove(K_SEARCHES).apply()
    }

    private fun readStringList(key: String): List<String> = try {
        val arr = JSONArray(sp.getString(key, "[]"))
        (0 until arr.length()).map { arr.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    // ---------- Data usage ----------
    @Synchronized
    fun addDataBytes(bytes: Long) {
        if (bytes <= 0) return
        val day = today()
        val base = if (sp.getString(K_DATA_DAY, null) == day) sp.getLong(K_DATA_BYTES, 0L) else 0L
        val total = base + bytes
        sp.edit().putString(K_DATA_DAY, day).putLong(K_DATA_BYTES, total).apply()
        _todayBytes.value = total
    }

    fun refreshTodayBytes() {
        _todayBytes.value = readTodayBytes()
    }

    private fun readTodayBytes(): Long =
        if (sp.getString(K_DATA_DAY, null) == today()) sp.getLong(K_DATA_BYTES, 0L) else 0L

    private fun today(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    companion object {
        const val IPTV_ORG_BASE = "https://iptv-org.github.io/iptv"

        val DEFAULT_SOURCES = listOf(
            PlaylistSource(
                id = "iptv-org-all",
                name = "iptv-org (all public channels)",
                url = "$IPTV_ORG_BASE/index.m3u",
                enabled = true,
                builtIn = true,
            )
        )

        private const val K_FAV = "favorites"
        private const val K_HISTORY = "history"
        private const val K_STATUS = "statuses"
        private const val K_SOURCES = "sources"
        private const val K_SEARCHES = "recent_searches"
        private const val K_LAST_REFRESH = "last_refresh"
        private const val K_WIFI_ONLY = "wifi_only"
        private const val K_WARN_MOBILE = "warn_mobile"
        private const val K_THEME = "theme"
        private const val K_DAILY_WARN = "daily_warn_mb"
        private const val K_DATA_DAY = "data_day"
        private const val K_DATA_BYTES = "data_bytes"
    }
}
