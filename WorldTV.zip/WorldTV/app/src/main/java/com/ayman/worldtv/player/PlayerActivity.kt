package com.ayman.worldtv.player

import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.TrafficStats
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.format.Formatter
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.PlaylistAdd
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.BrightnessMedium
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Headphones
import androidx.compose.material.icons.outlined.HighQuality
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PictureInPictureAlt
import androidx.compose.material.icons.outlined.ScreenRotation
import androidx.compose.material.icons.outlined.SignalCellularAlt
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Util
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.ayman.worldtv.R
import com.ayman.worldtv.app
import com.ayman.worldtv.data.NetType
import com.ayman.worldtv.data.NetworkUtils
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.model.DataSaverMode
import com.ayman.worldtv.model.StreamSource
import com.ayman.worldtv.ui.components.AddToListSheet
import com.ayman.worldtv.ui.components.ChannelLogo
import com.ayman.worldtv.ui.theme.WorldTvTheme
import com.ayman.worldtv.ui.theme.WtvColors
import com.ayman.worldtv.util.Countries
import com.ayman.worldtv.util.categoryLabel
import com.ayman.worldtv.util.countryName
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.math.roundToInt

private enum class Gate { NO_NETWORK, WIFI_ONLY, MOBILE_WARNING, DATA_LIMIT }

private data class QualityOption(val group: TrackGroup, val index: Int, val height: Int)

@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_ID = "channel_id"

        fun start(context: Context, channel: Channel, queue: List<Channel>) {
            val repo = context.app.repository
            repo.playQueue = queue.map { it.id }.ifEmpty { listOf(channel.id) }
            context.startActivity(
                Intent(context, PlayerActivity::class.java)
                    .putExtra(EXTRA_ID, channel.id)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
    }

    private val repo get() = app.repository

    // ----- Playback state (activity survives rotation thanks to configChanges) -----
    private var player by mutableStateOf<ExoPlayer?>(null)
    private var queue: List<String> = emptyList()
    private var index by mutableIntStateOf(0)
    private var streamIndex by mutableIntStateOf(0)
    private var forcedHls = false
    private var isPlaying by mutableStateOf(false)
    private var buffering by mutableStateOf(true)
    private var errorText by mutableStateOf<String?>(null)
    private var isLive by mutableStateOf(false)
    private var videoSize by mutableStateOf<Pair<Int, Int>?>(null)
    private var inPip by mutableStateOf(false)
    private var gate by mutableStateOf<Gate?>(null)
    private var sessionBytes by mutableLongStateOf(0L)
    private var allowMobileOnce = false
    private var dataWarningSeen = false
    private var lastRx = -1L
    private var meterJob: Job? = null
    private var waitJob: Job? = null

    // Quality
    private var qualityOptions by mutableStateOf<List<QualityOption>>(emptyList())
    private var qualityHeight by mutableStateOf<Int?>(null) // null = automatic
    private var dataSaverActive by mutableStateOf(false)

    // Sleep timer
    private var sleepEndsAt by mutableLongStateOf(0L)
    private var sleepJob: Job? = null

    // Gestures
    private var hud by mutableStateOf<Pair<ImageVector, String>?>(null)

    // Background audio
    private var audioOnlyRequested = false
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            isPlaying = playing
            updatePipParams()
            updateKeepScreenOn()
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            updateKeepScreenOn()
        }

        override fun onPlaybackStateChanged(state: Int) {
            buffering = state == Player.STATE_BUFFERING
            updateKeepScreenOn()
            if (state == Player.STATE_READY) {
                errorText = null
                isLive = player?.isCurrentMediaItemLive == true
                currentId()?.let { repo.markWorking(it) }
            }
        }

        override fun onVideoSizeChanged(size: VideoSize) {
            if (size.width > 0 && size.height > 0) {
                videoSize = size.width to size.height
                updatePipParams()
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            refreshQualityOptions(tracks)
        }

        override fun onPlayerError(error: PlaybackException) {
            handleError(error)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = savedInstanceState?.getString(EXTRA_ID)
            ?: intent.getStringExtra(EXTRA_ID)
            ?: PlayerHolder.channelId
        if (id == null) {
            finish()
            return
        }
        queue = repo.playQueue.takeIf { id in it } ?: listOf(id)
        index = queue.indexOf(id).coerceAtLeast(0)

        hideSystemBars()
        addOnPictureInPictureModeChangedListener { info -> inPip = info.isInPictureInPictureMode }

        setContent {
            WorldTvTheme(darkTheme = true) { PlayerScreen() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val id = intent.getStringExtra(EXTRA_ID) ?: return
        if (id == currentId()) return
        queue = repo.playQueue.takeIf { id in it } ?: listOf(id)
        index = queue.indexOf(id).coerceAtLeast(0)
        streamIndex = 0
        forcedHls = false
        loadCurrent()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        currentId()?.let { outState.putString(EXTRA_ID, it) }
    }

    override fun onStart() {
        super.onStart()
        audioOnlyRequested = false
        val p = PlayerHolder.obtain(this)
        p.addListener(listener)
        player = p
        connectSession()
        setVideoEnabled(true)
        if (meterJob == null) startMeter()
        if (PlayerHolder.channelId != null && PlayerHolder.channelId == currentId() &&
            p.playbackState != Player.STATE_IDLE
        ) {
            syncFromPlayer(p)
        } else {
            loadCurrent()
        }
        updateKeepScreenOn()
    }

    override fun onStop() {
        super.onStop()
        val p = player
        p?.removeListener(listener)
        val keepAudio = p != null && !isFinishing && !inPip && p.playWhenReady &&
            gate == null && errorText == null &&
            (audioOnlyRequested || repo.prefs.settings.value.backgroundAudio)
        if (keepAudio) {
            // Keep listening; drop the video track to save data and battery.
            setVideoEnabled(false)
        } else {
            stopMeter()
            waitJob?.cancel()
            PlayerHolder.release(this)
            player = null
            isPlaying = false
            cancelSleep()
        }
        releaseSession()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // The user closed the PiP window: end the session.
        if (inPip) finish()
    }

    override fun onDestroy() {
        if (PlayerHolder.player == null) stopMeter()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Android 12+ uses auto-enter (set in updatePipParams).
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && isPlaying && !backgroundAudioPreferred()) enterPip()
    }

    // ---------------- Session (notification + lock screen) ----------------

    private fun connectSession() {
        if (controllerFuture != null) return
        runCatching {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync()
        }
    }

    private fun releaseSession() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
    }

    private fun backgroundAudioPreferred() = repo.prefs.settings.value.backgroundAudio

    // ---------------- Loading ----------------

    private fun currentId(): String? = queue.getOrNull(index)

    private fun currentChannel(): Channel? = currentId()?.let { repo.catalog.value.byId[it] }

    private fun syncFromPlayer(p: ExoPlayer) {
        streamIndex = PlayerHolder.streamIndex
        isPlaying = p.isPlaying
        buffering = p.playbackState == Player.STATE_BUFFERING
        isLive = p.isCurrentMediaItemLive
        val vs = p.videoSize
        videoSize = if (vs.width > 0 && vs.height > 0) vs.width to vs.height else null
        refreshQualityOptions(p.currentTracks)
        errorText = null
        gate = null
    }

    private fun loadCurrent() {
        val p = player ?: return
        val channel = currentChannel()
        if (channel == null) {
            waitForCatalog()
            return
        }
        val blocked = evaluateGate()
        if (blocked != null) {
            gate = blocked
            buffering = false
            p.stop()
            return
        }
        gate = null
        errorText = null
        buffering = true
        isLive = false
        videoSize = null
        qualityOptions = emptyList()
        qualityHeight = null
        dataSaverActive = when (repo.prefs.settings.value.dataSaver) {
            DataSaverMode.OFF -> false
            DataSaverMode.ALWAYS -> true
            DataSaverMode.MOBILE_ONLY -> NetworkUtils.current(this) == NetType.METERED
        }
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            .setForceLowestBitrate(dataSaverActive)
            .build()
        val stream = channel.streams.getOrNull(streamIndex) ?: channel.streams.first()
        p.setMediaSource(buildSource(channel, stream, forcedHls))
        p.prepare()
        p.playWhenReady = true
        PlayerHolder.channelId = channel.id
        PlayerHolder.streamIndex = streamIndex
        repo.prefs.addHistory(channel.id)
    }

    /** After process death the catalog may still be loading from cache. */
    private fun waitForCatalog() {
        val id = currentId() ?: return
        buffering = true
        waitJob?.cancel()
        waitJob = lifecycleScope.launch {
            val found = withTimeoutOrNull(20_000) { repo.catalog.first { it.byId.containsKey(id) } }
            if (found != null) {
                loadCurrent()
            } else {
                buffering = false
                errorText = getString(R.string.channel_unavailable)
            }
        }
    }

    private fun evaluateGate(): Gate? {
        val settings = repo.prefs.settings.value
        val net = NetworkUtils.current(this)
        if (net == NetType.NONE) return Gate.NO_NETWORK
        if (net == NetType.METERED && !allowMobileOnce) {
            if (settings.wifiOnly) return Gate.WIFI_ONLY
            if (settings.warnOnMobile) return Gate.MOBILE_WARNING
        }
        val limit = settings.dailyWarningMb * 1_000_000L
        if (!dataWarningSeen && limit > 0 && repo.prefs.todayBytes.value >= limit) return Gate.DATA_LIMIT
        return null
    }

    private fun buildSource(channel: Channel, stream: StreamSource, forceHls: Boolean): MediaSource {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(stream.userAgent ?: Util.getUserAgent(this, "WorldTV"))
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        stream.referrer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }
        val factory = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))
        val lower = stream.url.lowercase()
        val metadata = MediaMetadata.Builder()
            .setTitle(channel.name)
            .setArtist(Countries.name(channel.countryCode, resources.configuration.locales[0]))
            .apply { channel.logo?.let { setArtworkUri(Uri.parse(it)) } }
            .build()
        val item = MediaItem.Builder()
            .setUri(stream.url)
            .setMediaId(channel.id)
            .setMediaMetadata(metadata)
        when {
            forceHls || lower.contains(".m3u8") -> item.setMimeType(MimeTypes.APPLICATION_M3U8)
            lower.contains(".mpd") -> item.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        return factory.createMediaSource(item.build())
    }

    private fun handleError(error: PlaybackException) {
        val p = player ?: return
        if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition()
            p.prepare()
            return
        }
        // Many IPTV links are HLS without a .m3u8 extension: retry once as HLS.
        val stream = currentChannel()?.streams?.getOrNull(streamIndex)
        val typeUnknown = stream != null && stream.url.lowercase().let { !it.contains(".m3u8") && !it.contains(".mpd") }
        val parseLike = error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
        if (!forcedHls && typeUnknown && parseLike) {
            forcedHls = true
            loadCurrent()
            return
        }
        buffering = false
        errorText = describe(error)
        currentId()?.let { repo.markFailed(it) }
    }

    private fun describe(e: PlaybackException): String {
        val http = generateSequence(e.cause) { it.cause }
            .filterIsInstance<HttpDataSource.InvalidResponseCodeException>()
            .firstOrNull()
        return when {
            http != null -> when (http.responseCode) {
                401, 403, 451 -> getString(R.string.err_forbidden)
                404, 410 -> getString(R.string.err_not_found)
                else -> getString(R.string.err_http, http.responseCode)
            }
            e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                getString(R.string.err_network)
            e.errorCode in 6000..6999 -> getString(R.string.err_drm)
            e.errorCode in 3000..4999 -> getString(R.string.err_format)
            else -> getString(R.string.err_generic)
        }
    }

    // ---------------- Quality ----------------

    private fun refreshQualityOptions(tracks: Tracks) {
        val options = mutableListOf<QualityOption>()
        for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSupported(i)) continue
                val height = group.getTrackFormat(i).height
                if (height > 0) options += QualityOption(group.mediaTrackGroup, i, height)
            }
        }
        qualityOptions = options.distinctBy { it.height }.sortedByDescending { it.height }
    }

    private fun selectAutoQuality(saver: Boolean) {
        val p = player ?: return
        dataSaverActive = saver
        qualityHeight = null
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            .setForceLowestBitrate(saver)
            .build()
    }

    private fun selectQuality(option: QualityOption) {
        val p = player ?: return
        dataSaverActive = false
        qualityHeight = option.height
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setForceLowestBitrate(false)
            .setOverrideForType(TrackSelectionOverride(option.group, option.index))
            .build()
    }

    private fun setVideoEnabled(enabled: Boolean) {
        val p = player ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !enabled)
            .build()
    }

    // ---------------- Actions ----------------

    private fun switchChannel(delta: Int) {
        if (queue.size < 2) return
        index = (index + delta + queue.size) % queue.size
        streamIndex = 0
        forcedHls = false
        loadCurrent()
    }

    private fun nextStream() {
        val channel = currentChannel() ?: return
        if (channel.streams.size < 2) return
        streamIndex = (streamIndex + 1) % channel.streams.size
        forcedHls = false
        loadCurrent()
    }

    private fun retry() {
        forcedHls = false
        loadCurrent()
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) {
            p.pause()
        } else {
            if (p.playbackState == Player.STATE_IDLE) p.prepare()
            if (isLive) p.seekToDefaultPosition()
            p.play()
        }
    }

    private fun toggleRotation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun acceptGate(g: Gate) {
        when (g) {
            Gate.WIFI_ONLY, Gate.MOBILE_WARNING -> allowMobileOnce = true
            Gate.DATA_LIMIT -> dataWarningSeen = true
            Gate.NO_NETWORK -> Unit
        }
        loadCurrent()
    }

    /** Leave the screen but keep the sound playing. */
    private fun listenInBackground() {
        audioOnlyRequested = true
        moveTaskToBack(true)
    }

    // ---------------- Sleep timer ----------------

    private fun startSleep(minutes: Int) {
        sleepJob?.cancel()
        sleepEndsAt = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = lifecycleScope.launch {
            delay(minutes * 60_000L)
            sleepEndsAt = 0L
            if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
                player?.pause()
            } else {
                // Listening in the background: stop completely.
                stopMeter()
                PlayerHolder.release(this@PlayerActivity)
                player = null
                finish()
            }
        }
    }

    private fun cancelSleep() {
        sleepJob?.cancel()
        sleepJob = null
        sleepEndsAt = 0L
    }

    // ---------------- Gestures: brightness, volume ----------------

    private fun currentBrightness(): Float {
        val value = window.attributes.screenBrightness
        if (value >= 0f) return value
        return runCatching {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        }.getOrDefault(0.5f)
    }

    private fun setBrightness(value: Float) {
        val attrs = window.attributes
        attrs.screenBrightness = value.coerceIn(0.02f, 1f)
        window.attributes = attrs
    }

    private fun audioManager() = getSystemService(AudioManager::class.java)

    private fun currentVolume(): Float {
        val am = audioManager() ?: return 0f
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    private fun setVolume(value: Float) {
        val am = audioManager() ?: return
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (value.coerceIn(0f, 1f) * max).roundToInt(), 0)
    }

    // ---------------- Screen / PiP ----------------

    /** Keep the screen awake only while a stream is playing or loading. */
    private fun updateKeepScreenOn() {
        val p = player
        val active = p != null && p.playWhenReady &&
            (p.playbackState == Player.STATE_READY || p.playbackState == Player.STATE_BUFFERING)
        if (active) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun pipSupported(): Boolean =
        packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun pipParams(): PictureInPictureParams {
        val (w, h) = videoSize ?: (16 to 9)
        val ratio = w.toFloat() / h
        val rational = when {
            ratio > 2.39f -> Rational(239, 100)
            ratio < 1f / 2.39f -> Rational(100, 239)
            else -> Rational(w, h)
        }
        val builder = PictureInPictureParams.Builder().setAspectRatio(rational)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(isPlaying && !backgroundAudioPreferred())
            builder.setSeamlessResizeEnabled(true)
        }
        return builder.build()
    }

    private fun updatePipParams() {
        if (!pipSupported()) return
        runCatching { setPictureInPictureParams(pipParams()) }
    }

    private fun enterPip() {
        if (!pipSupported()) return
        runCatching { enterPictureInPictureMode(pipParams()) }
    }

    // ---------------- Data meter (real bytes received by this app) ----------------

    private fun rxNow(): Long {
        val v = TrafficStats.getUidRxBytes(Process.myUid())
        return if (v < 0) -1L else v
    }

    private fun startMeter() {
        lastRx = rxNow()
        meterJob?.cancel()
        meterJob = lifecycleScope.launch {
            while (isActive) {
                delay(2_000)
                countData()
            }
        }
    }

    private fun stopMeter() {
        countData()
        meterJob?.cancel()
        meterJob = null
    }

    private fun countData() {
        val now = rxNow()
        if (now < 0 || lastRx < 0) return
        val delta = now - lastRx
        lastRx = now
        if (delta > 0) {
            sessionBytes += delta
            repo.prefs.addDataBytes(delta)
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------------- UI ----------------

    @Composable
    private fun PlayerScreen() {
        val catalog by repo.catalog.collectAsStateWithLifecycle()
        val favorites by repo.prefs.favorites.collectAsStateWithLifecycle()
        val channel = currentId()?.let { catalog.byId[it] }
        var controlsVisible by remember { mutableStateOf(true) }
        var showListSheet by remember { mutableStateOf(false) }
        var showSleepDialog by remember { mutableStateOf(false) }
        val labelNext = stringResource(R.string.next_channel)
        val labelPrev = stringResource(R.string.prev_channel)

        LaunchedEffect(controlsVisible, isPlaying, errorText, gate) {
            if (controlsVisible && isPlaying && errorText == null && gate == null) {
                delay(4_000)
                controlsVisible = false
            }
        }
        LaunchedEffect(hud) {
            if (hud != null) {
                delay(900)
                hud = null
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { controlsVisible = !controlsVisible })
                }
                .pointerInput(Unit) {
                    // Left edge: brightness. Right edge: volume. Middle: swipe up/down to change channel.
                    var zone = 0
                    var total = 0f
                    var start = 0f
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            total = 0f
                            zone = when {
                                offset.x < size.width * 0.3f -> 1
                                offset.x > size.width * 0.7f -> 2
                                else -> 0
                            }
                            start = when (zone) {
                                1 -> currentBrightness()
                                2 -> currentVolume()
                                else -> 0f
                            }
                        },
                        onDragEnd = {
                            if (zone == 0 && abs(total) > size.height * 0.12f && queue.size > 1) {
                                switchChannel(if (total < 0) 1 else -1)
                            }
                        },
                        onDragCancel = { },
                        onVerticalDrag = { change, dy ->
                            change.consume()
                            total += dy
                            if (zone == 0) {
                                if (abs(total) > size.height * 0.12f && queue.size > 1) {
                                    hud = if (total < 0) Icons.Outlined.KeyboardArrowUp to labelNext
                                    else Icons.Outlined.KeyboardArrowDown to labelPrev
                                }
                            } else {
                                val value = (start - total / (size.height * 0.8f)).coerceIn(0f, 1f)
                                if (zone == 1) setBrightness(value) else setVolume(value)
                                hud = (if (zone == 1) Icons.Outlined.BrightnessMedium else Icons.Outlined.VolumeUp) to
                                    "${(value * 100).roundToInt()}%"
                            }
                        },
                    )
                }
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                    }
                },
                update = { view -> view.player = player },
                modifier = Modifier.fillMaxSize(),
            )

            if (inPip) return@Box

            if (buffering && errorText == null && gate == null) {
                CircularProgressIndicator(
                    Modifier.align(Alignment.Center).size(56.dp),
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 3.dp,
                )
            }

            AnimatedVisibility(
                visible = controlsVisible && errorText == null && gate == null,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                Controls(
                    channel = channel,
                    favorite = channel != null && channel.id in favorites,
                    onAddToList = { showListSheet = true },
                    onSleep = { showSleepDialog = true },
                )
            }

            hud?.let { (icon, text) ->
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 72.dp)
                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(icon, contentDescription = null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text(text, color = Color.White, style = MaterialTheme.typography.titleSmall)
                }
            }

            val err = errorText
            if (err != null) {
                MessageOverlay(
                    icon = Icons.Outlined.ErrorOutline,
                    title = channel?.name ?: "",
                    message = err,
                ) {
                    Button(onClick = { retry() }) { Text(stringResource(R.string.retry)) }
                    if ((channel?.streams?.size ?: 0) > 1) {
                        OutlinedButton(onClick = { nextStream() }) {
                            Text(
                                stringResource(R.string.try_other_link) + " (" +
                                    stringResource(R.string.other_link, streamIndex + 1, channel!!.streams.size) + ")"
                            )
                        }
                    }
                    if (queue.size > 1) {
                        OutlinedButton(onClick = { switchChannel(1) }) { Text(stringResource(R.string.next_channel)) }
                    }
                    TextButton(onClick = { finish() }) { Text(stringResource(R.string.close)) }
                }
            }

            val g = gate
            if (g != null) {
                val (titleRes, message) = when (g) {
                    Gate.NO_NETWORK -> R.string.gate_offline_title to stringResource(R.string.gate_offline_msg)
                    Gate.WIFI_ONLY -> R.string.gate_wifi_title to stringResource(R.string.gate_wifi_msg)
                    Gate.MOBILE_WARNING -> R.string.gate_mobile_title to stringResource(R.string.gate_mobile_msg)
                    Gate.DATA_LIMIT -> R.string.gate_limit_title to stringResource(
                        R.string.gate_limit_msg,
                        Formatter.formatShortFileSize(this@PlayerActivity, repo.prefs.todayBytes.value),
                    )
                }
                MessageOverlay(
                    icon = if (g == Gate.NO_NETWORK) Icons.Outlined.WifiOff else Icons.Outlined.SignalCellularAlt,
                    title = stringResource(titleRes),
                    message = message,
                ) {
                    when (g) {
                        Gate.NO_NETWORK -> Button(onClick = { retry() }) { Text(stringResource(R.string.retry)) }
                        Gate.WIFI_ONLY -> Button(onClick = { acceptGate(g) }) { Text(stringResource(R.string.play_anyway)) }
                        else -> Button(onClick = { acceptGate(g) }) { Text(stringResource(R.string.continue_label)) }
                    }
                    TextButton(onClick = { finish() }) { Text(stringResource(R.string.close)) }
                }
            }
        }

        if (showListSheet && channel != null) {
            AddToListSheet(channel, onDismiss = { showListSheet = false })
        }

        if (showSleepDialog) {
            AlertDialog(
                onDismissRequest = { showSleepDialog = false },
                title = { Text(stringResource(R.string.sleep_timer)) },
                text = {
                    Column {
                        listOf(15, 30, 45, 60, 90).forEach { minutes ->
                            TextButton(onClick = { startSleep(minutes); showSleepDialog = false }) {
                                Text(stringResource(R.string.minutes, minutes))
                            }
                        }
                        if (sleepEndsAt > 0) {
                            TextButton(onClick = { cancelSleep(); showSleepDialog = false }) {
                                Text(stringResource(R.string.sleep_off), color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSleepDialog = false }) { Text(stringResource(R.string.close)) }
                },
            )
        }
    }

    @Composable
    private fun Controls(channel: Channel?, favorite: Boolean, onAddToList: () -> Unit, onSleep: () -> Unit) {
        var menuOpen by remember { mutableStateOf(false) }
        var qualityOpen by remember { mutableStateOf(false) }
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(sleepEndsAt) {
            while (sleepEndsAt > 0) {
                now = System.currentTimeMillis()
                delay(15_000)
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.75f),
                        0.35f to Color.Transparent,
                        0.65f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.75f),
                    )
                )
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            // Top bar
            Row(
                Modifier.align(Alignment.TopStart).fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OverlayIcon(Icons.AutoMirrored.Outlined.ArrowBack, stringResource(R.string.back)) { finish() }
                if (channel != null) {
                    ChannelLogo(channel.logo, channel.name, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            channel.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        val sub = buildString {
                            channel.countryCode?.let { append(Countries.flag(it)).append(' ') }
                            append(countryName(channel.countryCode))
                            if (isNotBlank()) append(" · ")
                            append(categoryLabel(channel.primaryCategory))
                        }
                        Text(
                            sub,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.75f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                } else {
                    Spacer(Modifier.weight(1f))
                }
                if (isLive) LiveBadge()
                if (channel != null) {
                    OverlayIcon(
                        if (favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        stringResource(if (favorite) R.string.remove_favorite else R.string.add_favorite),
                        tint = if (favorite) MaterialTheme.colorScheme.primary else Color.White,
                    ) { repo.prefs.toggleFavorite(channel.id) }
                }
                Box {
                    OverlayIcon(Icons.Outlined.MoreVert, stringResource(R.string.more)) { menuOpen = true }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        if (channel != null) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.add_to_list)) },
                                leadingIcon = { Icon(Icons.AutoMirrored.Outlined.PlaylistAdd, null) },
                                onClick = { menuOpen = false; onAddToList() },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.sleep_timer)) },
                            leadingIcon = { Icon(Icons.Outlined.Bedtime, null) },
                            onClick = { menuOpen = false; onSleep() },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.listen_background)) },
                            leadingIcon = { Icon(Icons.Outlined.Headphones, null) },
                            onClick = { menuOpen = false; listenInBackground() },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.rotate)) },
                            leadingIcon = { Icon(Icons.Outlined.ScreenRotation, null) },
                            onClick = { menuOpen = false; toggleRotation() },
                        )
                        if (pipSupported()) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.pip)) },
                                leadingIcon = { Icon(Icons.Outlined.PictureInPictureAlt, null) },
                                onClick = { menuOpen = false; enterPip() },
                            )
                        }
                    }
                }
            }

            // Center controls
            Row(
                Modifier.align(Alignment.Center),
                horizontalArrangement = Arrangement.spacedBy(32.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (queue.size > 1) {
                    OverlayIcon(Icons.Filled.SkipPrevious, stringResource(R.string.prev_channel), size = 56) { switchChannel(-1) }
                }
                if (!buffering) {
                    FilledIconButton(
                        onClick = { togglePlay() },
                        modifier = Modifier.size(72.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                    ) {
                        Icon(
                            if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = stringResource(if (isPlaying) R.string.pause else R.string.play),
                            modifier = Modifier.size(36.dp),
                        )
                    }
                } else {
                    Spacer(Modifier.size(72.dp))
                }
                if (queue.size > 1) {
                    OverlayIcon(Icons.Filled.SkipNext, stringResource(R.string.next_channel), size = 56) { switchChannel(1) }
                }
            }

            // Bottom bar
            Row(
                Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box {
                    val label = when {
                        qualityHeight != null -> "${qualityHeight}p"
                        dataSaverActive -> stringResource(R.string.data_saver)
                        else -> stringResource(R.string.quality_auto)
                    }
                    TextButton(onClick = { qualityOpen = true }) {
                        Icon(Icons.Outlined.HighQuality, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(label, color = Color.White)
                    }
                    DropdownMenu(expanded = qualityOpen, onDismissRequest = { qualityOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.quality_auto)) },
                            onClick = { selectAutoQuality(false); qualityOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.data_saver_lowest)) },
                            onClick = { selectAutoQuality(true); qualityOpen = false },
                        )
                        if (qualityOptions.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.quality_single)) },
                                onClick = { qualityOpen = false },
                                enabled = false,
                            )
                        }
                        qualityOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text("${option.height}p") },
                                onClick = { selectQuality(option); qualityOpen = false },
                            )
                        }
                    }
                }
                if (channel != null && channel.streams.size > 1) {
                    TextButton(onClick = { nextStream() }) {
                        Text(stringResource(R.string.other_link, streamIndex + 1, channel.streams.size), color = Color.White)
                    }
                }
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    if (sleepEndsAt > 0) {
                        val minutesLeft = ((sleepEndsAt - now) / 60_000L).coerceAtLeast(0L) + 1
                        Text(
                            stringResource(R.string.sleep_in, minutesLeft.toInt()),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    val size = videoSize
                    val info = buildString {
                        if (size != null) append("${size.first}×${size.second}")
                        if (sessionBytes > 0) {
                            if (isNotEmpty()) append("  ·  ")
                            append(Formatter.formatShortFileSize(this@PlayerActivity, sessionBytes))
                        }
                    }
                    if (info.isNotEmpty()) {
                        Text(info, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
                    }
                }
                Spacer(Modifier.width(8.dp))
            }
        }
    }

    @Composable
    private fun LiveBadge() {
        Box(
            Modifier
                .padding(horizontal = 6.dp)
                .background(WtvColors.Live, RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                stringResource(R.string.live),
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
            )
        }
    }

    @Composable
    private fun OverlayIcon(
        icon: ImageVector,
        description: String,
        tint: Color = Color.White,
        size: Int = 48,
        onClick: () -> Unit,
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(size.dp)) {
            Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size((size / 2).dp))
        }
    }

    @Composable
    private fun MessageOverlay(
        icon: ImageVector,
        title: String,
        message: String,
        actions: @Composable () -> Unit,
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.82f))
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier.widthIn(max = 420.dp).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
                if (title.isNotBlank()) {
                    Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White, textAlign = TextAlign.Center)
                }
                Text(
                    message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(6.dp))
                actions()
            }
        }
    }
}
