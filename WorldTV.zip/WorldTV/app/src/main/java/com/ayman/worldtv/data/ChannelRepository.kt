package com.ayman.worldtv.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.ayman.worldtv.model.Catalog
import com.ayman.worldtv.model.CategoryCount
import com.ayman.worldtv.model.Channel
import com.ayman.worldtv.model.ChannelStatus
import com.ayman.worldtv.model.CheckProgress
import com.ayman.worldtv.model.CountryCount
import com.ayman.worldtv.model.PlaylistSource
import com.ayman.worldtv.util.Categories
import com.ayman.worldtv.util.Countries
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Single source of truth for the channel catalog.
 * Downloads enabled playlists, caches them on disk, and works offline from the cache.
 * No background polling: refresh happens on app start (if stale) or when the user asks.
 */
class ChannelRepository(private val context: Context, val prefs: Prefs) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    private val _catalog = MutableStateFlow(Catalog(loading = true))
    val catalog: StateFlow<Catalog> = _catalog.asStateFlow()

    private val _checkProgress = MutableStateFlow<CheckProgress?>(null)
    val checkProgress: StateFlow<CheckProgress?> = _checkProgress.asStateFlow()

    private val checkHttp = http.newBuilder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    /** Channel ids the player can step through with next/previous. */
    @Volatile
    var playQueue: List<String> = emptyList()

    init {
        scope.launch {
            rebuildFromCache()
            val stale = System.currentTimeMillis() - prefs.lastRefresh > STALE_AFTER_MS
            if (stale || _catalog.value.channels.isEmpty()) refresh()
            else _catalog.update { it.copy(loading = false) }
        }
    }

    fun refreshAsync() {
        scope.launch { refresh() }
    }

    fun rebuildAsync() {
        scope.launch { rebuildFromCache() }
    }

    suspend fun refresh() = mutex.withLock {
        _catalog.update { it.copy(loading = true) }
        val errors = mutableListOf<String>()
        var usedCache = false
        val texts = mutableListOf<String>()
        val enabled = prefs.sources.value.filter { it.enabled }
        for (source in enabled) {
            val file = cacheFile(source)
            if (source.isLocal) {
                if (file.exists()) texts += file.readText()
                continue
            }
            try {
                val text = download(source.url)
                file.writeText(text)
                texts += text
            } catch (e: Exception) {
                errors += "${source.name}: ${e.message ?: e.javaClass.simpleName}"
                if (file.exists()) {
                    texts += file.readText()
                    usedCache = true
                }
            }
        }
        if (errors.isEmpty()) prefs.lastRefresh = System.currentTimeMillis()
        val built = withContext(Dispatchers.Default) { build(texts) }
        _catalog.value = built.copy(
            loading = false,
            sourceErrors = errors,
            usingCache = usedCache,
            sourceCount = enabled.size,
            lastUpdated = prefs.lastRefresh,
        )
    }

    private suspend fun rebuildFromCache() = mutex.withLock {
        val enabled = prefs.sources.value.filter { it.enabled }
        val texts = enabled.mapNotNull { s -> cacheFile(s).takeIf { it.exists() }?.readText() }
        val built = withContext(Dispatchers.Default) { build(texts) }
        _catalog.update { old ->
            built.copy(
                loading = old.loading,
                sourceErrors = old.sourceErrors,
                usingCache = old.usingCache,
                sourceCount = enabled.size,
                lastUpdated = prefs.lastRefresh,
            )
        }
    }

    // ---------- Sources ----------

    fun addUrlSource(name: String, url: String) {
        prefs.addSource(name.ifBlank { url.substringAfterLast('/') }, url.trim())
        refreshAsync()
    }

    fun removeSource(source: PlaylistSource) {
        cacheFile(source).delete()
        prefs.removeSource(source.id)
        rebuildAsync()
    }

    fun setSourceEnabled(source: PlaylistSource, enabled: Boolean) {
        prefs.setSourceEnabled(source.id, enabled)
        val cached = cacheFile(source).exists()
        if (enabled && !cached && !source.isLocal) refreshAsync() else rebuildAsync()
    }

    /** Imports a local M3U file. Returns the number of channels found, or -1 if invalid. */
    suspend fun importLocalPlaylist(uri: Uri): Int = withContext(Dispatchers.IO) {
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = input.readBytes()
                if (buffer.size > MAX_PLAYLIST_BYTES) throw IOException("File too large")
                buffer
            } ?: return@withContext -1
            val text = String(bytes, Charsets.UTF_8)
            val count = M3uParser.parse(text).size
            if (count == 0) return@withContext -1
            val name = displayName(uri) ?: "Imported playlist"
            val source = prefs.addSource(name, "local:" + System.currentTimeMillis())
            cacheFile(source).writeText(text)
            rebuildFromCache()
            count
        } catch (e: Exception) {
            -1
        }
    }

    private fun displayName(uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    // ---------- Status ----------

    fun markWorking(id: String) = prefs.setStatus(id, ChannelStatus.WORKING)
    fun markFailed(id: String) = prefs.setStatus(id, ChannelStatus.FAILED)

    // ---------- Link check ----------

    /**
     * Lightly checks whether each channel's links answer. Max 150 channels, 4 at a time,
     * one request per link, so it never hammers broadcasters.
     * A responding link is NOT proof the channel plays, so it's stored as REACHABLE, not WORKING.
     */
    fun checkChannels(ids: List<String>) {
        if (_checkProgress.value != null) return
        val channels = ids.distinct().mapNotNull { _catalog.value.byId[it] }.take(150)
        if (channels.isEmpty()) return
        _checkProgress.value = CheckProgress(0, channels.size)
        scope.launch {
            val semaphore = Semaphore(4)
            coroutineScope {
                channels.forEach { ch ->
                    launch {
                        semaphore.withPermit {
                            val ok = probe(ch)
                            val previous = prefs.statuses.value[ch.id]?.status
                            val status = when {
                                ok && previous == ChannelStatus.WORKING -> ChannelStatus.WORKING
                                ok -> ChannelStatus.REACHABLE
                                else -> ChannelStatus.UNREACHABLE
                            }
                            prefs.setStatus(ch.id, status)
                            _checkProgress.update { it?.copy(done = it.done + 1) }
                        }
                    }
                }
            }
            _checkProgress.value = null
        }
    }

    private fun probe(channel: Channel): Boolean {
        for (stream in channel.streams.take(2)) {
            try {
                val builder = Request.Builder().url(stream.url)
                    .header("User-Agent", stream.userAgent ?: "WorldTV/1.0 (Android)")
                stream.referrer?.let { builder.header("Referer", it) }
                checkHttp.newCall(builder.build()).execute().use { response ->
                    if (!response.isSuccessful) return@use
                    val body = response.body ?: return@use
                    val type = body.contentType()?.toString()?.lowercase().orEmpty()
                    val looksHls = stream.url.lowercase().contains(".m3u8") || type.contains("mpegurl")
                    if (!looksHls) return true
                    val buffer = ByteArray(8192)
                    val read = body.byteStream().read(buffer)
                    if (read > 0 && String(buffer, 0, read).contains("#EXTM3U")) return true
                }
            } catch (e: Exception) {
                // try the next link
            }
        }
        return false
    }

    // ---------- Internals ----------

    private fun cacheFile(source: PlaylistSource) =
        File(context.filesDir, "playlist_${source.id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.m3u")

    private fun download(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", "WorldTV/1.0 (Android)").build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            val body = response.body ?: throw IOException("Empty response")
            if (body.contentLength() > MAX_PLAYLIST_BYTES) throw IOException("Playlist too large")
            val text = body.string()
            if (!text.contains("#EXTINF", ignoreCase = true)) throw IOException("Not an M3U playlist")
            return text
        }
    }

    private fun build(texts: List<String>): Catalog {
        val map = LinkedHashMap<String, Channel>()
        for (text in texts) {
            for (e in M3uParser.parse(text)) {
                val existing = map[e.id]
                if (existing == null) {
                    map[e.id] = Channel(
                        id = e.id,
                        name = e.name,
                        normName = TextNormalizer.normalize(e.name),
                        logo = e.logo,
                        countryCode = e.country,
                        categories = e.categories,
                        languages = e.languages,
                        streams = listOf(e.stream),
                        geoBlocked = e.geoBlocked,
                        notAlwaysOn = e.notAlwaysOn,
                        searchKey = searchKey(e.name, e.country, e.categories, e.languages),
                    )
                } else if (existing.streams.none { it.url == e.stream.url }) {
                    val cats = (existing.categories + e.categories).distinct()
                        .let { list -> if (list.size > 1) list - "undefined" else list }
                    val langs = (existing.languages + e.languages).distinct()
                    map[e.id] = existing.copy(
                        logo = existing.logo ?: e.logo,
                        countryCode = existing.countryCode ?: e.country,
                        categories = cats,
                        languages = langs,
                        streams = existing.streams + e.stream,
                        geoBlocked = existing.geoBlocked && e.geoBlocked,
                        notAlwaysOn = existing.notAlwaysOn && e.notAlwaysOn,
                        searchKey = searchKey(existing.name, existing.countryCode ?: e.country, cats, langs),
                    )
                }
            }
        }
        val list = map.values.sortedBy { it.normName }
        val countries = list.mapNotNull { it.countryCode }
            .groupingBy { it }.eachCount()
            .map { CountryCount(it.key, it.value) }
            .sortedByDescending { it.count }
        val categories = list.flatMap { it.categories }
            .groupingBy { it }.eachCount()
            .map { CategoryCount(it.key, it.value) }
            .sortedByDescending { it.count }
        val languages = list.flatMap { it.languages }.distinct().sorted()
        return Catalog(
            channels = list,
            byId = list.associateBy { it.id },
            countries = countries,
            categories = categories,
            languages = languages,
        )
    }

    private fun searchKey(name: String, country: String?, categories: List<String>, languages: List<String>): String {
        val sb = StringBuilder(name)
        if (country != null) {
            sb.append(' ').append(country)
                .append(' ').append(Countries.name(country, Locale.ENGLISH))
                .append(' ').append(Countries.name(country, Countries.ARABIC))
        }
        for (c in categories) {
            sb.append(' ').append(c)
            Categories.arabicSynonyms[c]?.let { sb.append(' ').append(it) }
        }
        for (l in languages) sb.append(' ').append(l)
        return TextNormalizer.normalize(sb.toString())
    }

    companion object {
        private const val STALE_AFTER_MS = 12L * 60 * 60 * 1000
        private const val MAX_PLAYLIST_BYTES = 25L * 1024 * 1024
    }
}
