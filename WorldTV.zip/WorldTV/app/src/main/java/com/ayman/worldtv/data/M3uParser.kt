package com.ayman.worldtv.data

import com.ayman.worldtv.model.StreamSource

/** Parses extended M3U playlists (iptv-org style and most IPTV exports). */
object M3uParser {

    data class Entry(
        val id: String,
        val name: String,
        val logo: String?,
        val country: String?,
        val categories: List<String>,
        val languages: List<String>,
        val stream: StreamSource,
        val geoBlocked: Boolean,
        val notAlwaysOn: Boolean,
    )

    private val attrRegex = Regex("""([A-Za-z0-9_-]+)="([^"]*)"""")
    private val qualityRegex = Regex("""\((\d{3,4}p)\)""")
    private val bracketRegex = Regex("""\[[^\]]*\]""")
    private val qualityStrip = Regex("""\s*\(\d{3,4}p\)""")

    fun parse(text: String): List<Entry> {
        val out = ArrayList<Entry>()
        var info: String? = null
        var ua: String? = null
        var ref: String? = null
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.isEmpty() -> Unit
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    info = line; ua = null; ref = null
                }
                line.startsWith("#EXTVLCOPT", ignoreCase = true) -> {
                    val opt = line.substringAfter(':')
                    val key = opt.substringBefore('=').trim().lowercase()
                    val value = opt.substringAfter('=', "").trim()
                    if (key == "http-user-agent") ua = value.ifBlank { null }
                    if (key == "http-referrer" || key == "http-referer") ref = value.ifBlank { null }
                }
                line.startsWith("#") -> Unit
                else -> {
                    val current = info
                    if (current != null && isPlayableUrl(line)) {
                        out += buildEntry(current, line, ua, ref)
                    }
                    info = null; ua = null; ref = null
                }
            }
        }
        return out
    }

    private fun isPlayableUrl(url: String): Boolean =
        url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)

    private fun buildEntry(info: String, url: String, ua: String?, ref: String?): Entry {
        val attrs = HashMap<String, String>()
        attrRegex.findAll(info).forEach { attrs[it.groupValues[1].lowercase()] = it.groupValues[2].trim() }

        val lastQuote = info.lastIndexOf('"')
        val comma = info.indexOf(',', if (lastQuote >= 0) lastQuote else 0)
        var rawName = if (comma >= 0) info.substring(comma + 1).trim() else ""
        if (rawName.isEmpty()) rawName = attrs["tvg-name"].orEmpty()

        val quality = qualityRegex.find(rawName)?.groupValues?.get(1)
        val geo = rawName.contains("[Geo-blocked]", ignoreCase = true)
        val notAlways = rawName.contains("[Not 24/7]", ignoreCase = true)
        val cleaned = rawName.replace(bracketRegex, "").replace(qualityStrip, "").trim()
        val name = cleaned.ifEmpty {
            attrs["tvg-name"]?.takeIf { it.isNotBlank() } ?: url.substringAfter("//").substringBefore('/')
        }

        val tvgId = attrs["tvg-id"].orEmpty()
        val country = normalizeCountry(attrs["tvg-country"]?.split(';', ',')?.firstOrNull())
            ?: countryFromId(tvgId)
        val categories = attrs["group-title"].orEmpty()
            .split(';')
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .ifEmpty { listOf("undefined") }
        val languages = attrs["tvg-language"].orEmpty()
            .split(';', ',')
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val id = if (tvgId.isNotBlank()) tvgId.lowercase()
        else "n:" + TextNormalizer.normalize(name) + "|" + (country ?: "")

        val userAgent = ua ?: attrs["http-user-agent"] ?: attrs["user-agent"]
        val referrer = ref ?: attrs["http-referrer"] ?: attrs["referrer"]

        return Entry(
            id = id,
            name = name,
            logo = attrs["tvg-logo"]?.takeIf { it.startsWith("http", ignoreCase = true) },
            country = country,
            categories = categories,
            languages = languages,
            stream = StreamSource(
                url = url,
                userAgent = userAgent?.takeIf { it.isNotBlank() },
                referrer = referrer?.takeIf { it.isNotBlank() },
                quality = quality,
            ),
            geoBlocked = geo,
            notAlwaysOn = notAlways,
        )
    }

    private fun normalizeCountry(code: String?): String? {
        val c = code?.trim()?.lowercase() ?: return null
        if (c.length != 2 || !c.all { it in 'a'..'z' }) return null
        return if (c == "uk") "GB" else c.uppercase()
    }

    private fun countryFromId(tvgId: String): String? {
        val base = tvgId.substringBefore('@')
        val dot = base.lastIndexOf('.')
        if (dot < 0) return null
        return normalizeCountry(base.substring(dot + 1))
    }
}
