# World TV

Native Android live TV player (Kotlin, Jetpack Compose, Media3 ExoPlayer).

## Build on GitHub (no computer needed)
1. Upload `WorldTV.zip` (as is, not extracted) to the root of your repo.
2. Put `build.yml` in `.github/workflows/build.yml`.
3. Open the Actions tab, run "Build World TV APK", download the `WorldTV-debug-apk` artifact.

A fixed debug key (`app/debug.keystore`) is included so new builds install over old ones.

## What's in v1.0
- Home: continue watching, recently watched, favorites, categories, top countries
- Explore: Arabic + English search (letter normalization), filters, sort, recent searches
- Countries directory, Favorites, Settings
- Player: HLS/DASH, auto-hide controls, next/previous channel, alternate links,
  live badge only for real live streams, PiP, rotation, clear error messages
- Wi-Fi only mode, mobile data warning, measured daily data usage
- Sources: iptv-org public playlist by default, add any M3U link, import M3U file
- Arabic/English UI with RTL, dark/light theme

## Not in v1.0
- TV Guide (EPG): iptv-org does not publish ready XMLTV files, so this needs its own phase.
- Chromecast, Android TV layout, release AAB signing for Google Play.
